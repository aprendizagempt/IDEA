
import { GoogleGenAI, Type } from "@google/genai";
import { AIEstimate } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("Gemini API key not found. AI features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

interface EstimateFormData {
    service: string;
    urgency: string;
    location: string;
    description: string;
}

export const getAiEstimate = async (formData: EstimateFormData): Promise<AIEstimate> => {
    if (!API_KEY) {
        throw new Error("Chave de API não configurada. A funcionalidade do simulador está desativada.");
    }

    const prompt = `Age como um estimador de custos para serviços em Portugal. Com base nos seguintes detalhes, forneça uma estimativa de preço em Euros.
- Tipo de Serviço: ${formData.service}
- Urgência: ${formData.urgency} (${formData.urgency === 'urgente' ? 'taxa de urgência pode ser aplicada' : 'agendamento normal'})
- Localização (cidade/região): ${formData.location}
- Descrição do Trabalho: ${formData.description}
Forneça a sua resposta estritamente no formato JSON, seguindo o schema fornecido. O custo deve ser um intervalo (mínimo e máximo). A desagregação deve incluir itens como 'Mão de obra', 'Materiais (se aplicável)', 'Deslocação', 'Taxa de Urgência (se aplicável)'. As notas devem incluir quaisquer suposições que fez.`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        estimated_cost_min: { type: Type.NUMBER, description: "O custo mínimo estimado." },
                        estimated_cost_max: { type: Type.NUMBER, description: "O custo máximo estimado." },
                        currency: { type: Type.STRING, description: "A moeda da estimativa, e.g., 'EUR'." },
                        breakdown: {
                            type: Type.ARRAY,
                            description: "Uma lista dos componentes do custo.",
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    item: { type: Type.STRING, description: "O nome do item do custo, e.g., 'Mão de obra'." },
                                    cost: { type: Type.STRING, description: "O custo ou intervalo de custo para o item." }
                                },
                                required: ["item", "cost"]
                            }
                        },
                        notes: { type: Type.STRING, description: "Quaisquer notas ou suposições feitas para a estimativa." }
                    },
                    required: ["estimated_cost_min", "estimated_cost_max", "currency", "breakdown", "notes"]
                },
            },
        });
        
        const jsonText = response.text.trim();
        const jsonResponse: AIEstimate = JSON.parse(jsonText);
        return jsonResponse;
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Não foi possível obter uma estimativa da IA. O serviço pode estar temporariamente indisponível.");
    }
};

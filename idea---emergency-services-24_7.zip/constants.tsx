
import React from 'react';
import { ServiceCategory, Testimonial, ServiceProvider, PostalCodeData, MapMarkerData, PricingPlan, PaymentMethod } from './types';
import { WrenchScrewdriverIcon } from './components/icons/WrenchScrewdriverIcon';
import { UserGroupIcon } from './components/icons/UserGroupIcon';
import { HomeModernIcon } from './components/icons/HomeModernIcon';
import { ScaleIcon } from './components/icons/ScaleIcon';
import { PaintBrushIcon } from './components/icons/PaintBrushIcon';
import { TruckIcon } from './components/icons/TruckIcon';
import { LightBulbIcon } from './components/icons/LightBulbIcon';
import { SparklesIcon } from './components/icons/SparklesIcon';
import { BuildingStorefrontIcon } from './components/icons/BuildingStorefrontIcon';
import { BriefcaseIcon } from './components/icons/BriefcaseIcon';
import { ComputerDesktopIcon } from './components/icons/ComputerDesktopIcon';
import { KeyIcon } from './components/icons/KeyIcon';
import { CakeIcon } from './components/icons/CakeIcon';
import { CameraIcon } from './components/icons/CameraIcon';
import { AcademicCapIcon } from './components/icons/AcademicCapIcon';
import { MusicalNoteIcon } from './components/icons/MusicalNoteIcon';
import { HeartIcon } from './components/icons/HeartIcon';
import { DogIcon } from './components/icons/DogIcon';
import { GlobeAltIcon } from './components/icons/GlobeAltIcon';
import { BoltIcon } from './components/icons/BoltIcon';
import { CheckBadgeIcon } from './components/icons/CheckBadgeIcon';
import { MagnifyingGlassIcon } from './components/icons/MagnifyingGlassIcon';
import { WashingMachineIcon } from './components/icons/WashingMachineIcon';
import { CarIcon } from './components/icons/CarIcon';
import { ScissorsIcon } from './components/icons/ScissorsIcon';
import { MbWayIcon } from './components/icons/MbWayIcon';
import { PayPalIcon } from './components/icons/PayPalIcon';
import { VisaIcon } from './components/icons/VisaIcon';
import { MastercardIcon } from './components/icons/MastercardIcon';
import { DirectDebitIcon } from './components/icons/DirectDebitIcon';


export const SERVICE_CATEGORIES: ServiceCategory[] = [
    { name: 'Canalizadores', icon: WrenchScrewdriverIcon }, { name: 'Babysitters', icon: UserGroupIcon }, { name: 'Pedreiros', icon: HomeModernIcon }, { name: 'Advogados', icon: ScaleIcon }, { name: 'Pintores', icon: PaintBrushIcon }, { name: 'Mudanças', icon: TruckIcon }, { name: 'Eletricistas', icon: LightBulbIcon }, { name: 'Limpeza Doméstica', icon: SparklesIcon }, { name: 'Jardineiros', icon: BuildingStorefrontIcon }, { name: 'Carpinteiros', icon: BriefcaseIcon }, { name: 'Web Developers', icon: ComputerDesktopIcon }, { name: 'Contabilistas', icon: BriefcaseIcon }, { name: 'Serralheiros', icon: KeyIcon }, { name: 'Catering', icon: CakeIcon }, { name: 'Fotógrafos', icon: CameraIcon }, { name: 'Explicações', icon: AcademicCapIcon }, { name: 'Aulas de Música', icon: MusicalNoteIcon }, { name: 'Personal Trainers', icon: HeartIcon }, { name: 'Dog Walkers', icon: DogIcon }, { name: 'Reparação de Eletrodomésticos', icon: WrenchScrewdriverIcon }, { name: 'Montagem de Móveis', icon: WrenchScrewdriverIcon }, { name: 'Designers Gráficos', icon: PaintBrushIcon }, { name: 'Arquitetos', icon: HomeModernIcon }, { name: 'Decoradores de Interiores', icon: HomeModernIcon }, { name: 'Cuidados a Idosos', icon: HeartIcon }, { name: 'Traduções', icon: GlobeAltIcon }, { name: 'Organização de Eventos', icon: UserGroupIcon }, { name: 'Técnicos de AVAC', icon: BoltIcon }, { name: 'Estofadores', icon: BriefcaseIcon }, { name: 'Serviços de TI', icon: ComputerDesktopIcon }, { name: 'Reparação de Telemóveis', icon: ComputerDesktopIcon }, { name: 'Videógrafos', icon: CameraIcon }, { name: 'DJs', icon: MusicalNoteIcon }, { name: 'Segurança', icon: CheckBadgeIcon }, { name: 'Motoristas Particulares', icon: TruckIcon }, { name: 'Consultoria de Negócios', icon: BriefcaseIcon }, { name: 'Marketing Digital', icon: MagnifyingGlassIcon }, { name: 'Nutricionistas', icon: HeartIcon }, { name: 'Chef em Casa', icon: CakeIcon }, { name: 'Lavagem de Carros', icon: SparklesIcon }, { name: 'Controlo de Pragas', icon: BoltIcon }, { name: 'Remodelações', icon: HomeModernIcon }, { name: 'Isolamentos', icon: HomeModernIcon }, { name: 'Polimento de Pavimentos', icon: SparklesIcon }, { name: 'Reparação de Estores', icon: WrenchScrewdriverIcon }, { name: 'Aulas de Culinária', icon: CakeIcon }, { name: 'Apoio Administrativo', icon: BriefcaseIcon }, { name: 'Limpeza Predial', icon: BuildingStorefrontIcon }, { name: 'Lavandaria', icon: WashingMachineIcon }, { name: 'Desinfestação', icon: BoltIcon }, { name: 'Instalação de Ar Condicionado', icon: BoltIcon }, { name: 'Reparação de Telhados', icon: HomeModernIcon }, { name: 'Manicure/Pedicure', icon: SparklesIcon }, { name: 'Cabeleireiro ao Domicílio', icon: ScissorsIcon }, { name: 'Massagista', icon: HeartIcon }, { name: 'Animação de Festas', icon: CakeIcon }, { name: 'Florista', icon: SparklesIcon }, { name: 'Mecânico de Automóveis', icon: CarIcon }, { name: 'Reboque de Veículos', icon: TruckIcon }, { name: 'Gestão de Redes Sociais', icon: GlobeAltIcon }, { name: 'Aulas de Condução', icon: CarIcon }, { name: 'Aulas de Yoga', icon: HeartIcon }, { name: 'Aulas de Dança', icon: MusicalNoteIcon },
];

export const ALL_SERVICES = Array.from(new Set(SERVICE_CATEGORIES.map(s => s.name))).sort();

export const TESTIMONIALS: Testimonial[] = [
    { id: 1, client: 'Cliente Anónimo #3451', service: 'Canalização Urgente', rating: 5, comment: 'Serviço impecável e super rápido! O profissional chegou em 30 minutos e resolveu o problema da minha fuga de água. Recomendo vivamente!', avatar: `https://picsum.photos/seed/client1/100/100` },
    { id: 2, client: 'Cliente Anónimo #7823', service: 'Pintura de Apartamento', rating: 4.7, comment: 'A equipa foi muito profissional e o resultado final ficou excelente. Apenas um pequeno atraso no início, mas compensado pela qualidade.', avatar: `https://picsum.photos/seed/client2/100/100` },
    { id: 3, client: 'Cliente Anónimo #9012', service: 'Babysitting', rating: 5, comment: 'A Maria foi fantástica com os meus filhos. Chegou a horas, foi muito atenciosa e as crianças adoraram-na. Senti-me completamente segura.', avatar: `https://picsum.photos/seed/client3/100/100` },
    { id: 4, client: 'Cliente Anónimo #5548', service: 'Remodelação de Cozinha', rating: 4.9, comment: 'Projeto complexo, mas executado com grande mestria. A comunicação foi clara e o orçamento foi cumprido. Muito satisfeito.', avatar: `https://picsum.photos/seed/client4/100/100` },
];

export const SERVICE_PROVIDERS: ServiceProvider[] = [
    { id: 1, name: 'Canalizadores Toledo & Filhos', category: 'Canalizadores', rating: 4.9, jobsCompleted: 152, description: 'Especialista em reparações urgentes 24/7, desentupimentos e novas instalações de canalização.', zones: ['Porto', 'Vila Nova de Gaia', 'Matosinhos'], membershipLevel: 'VIP', memberSince: '2023-01-15T10:00:00Z', avatar: 'https://picsum.photos/seed/provider1/100/100' }, 
    { id: 2, name: 'Eletro-Segura Instalações', category: 'Eletricistas', rating: 4.8, jobsCompleted: 213, description: 'Instalações elétricas certificadas e resolução de avarias com piquete de urgência.', zones: ['Lisboa', 'Amadora', 'Sintra'], membershipLevel: 'Profissional', memberSince: '2022-11-20T14:30:00Z', avatar: 'https://picsum.photos/seed/provider2/100/100' }, 
    { id: 3, name: 'Pinturas & Remodelações Arte Nova', category: 'Pintores', rating: 5.0, jobsCompleted: 88, description: 'Pintura interior e exterior com acabamentos perfeitos e aconselhamento de cores.', zones: ['Faro', 'Loulé', 'Albufeira'], membershipLevel: 'Normal', memberSince: '2024-03-10T09:00:00Z', avatar: 'https://picsum.photos/seed/provider3/100/100' }, 
    { id: 4, name: 'Limpezas Brilho Total', category: 'Limpeza Doméstica', rating: 4.7, jobsCompleted: 300, description: 'Serviços de limpeza profunda para residências, escritórios e condomínios.', zones: ['Coimbra', 'Figueira da Foz'], membershipLevel: 'Profissional', memberSince: '2023-05-01T08:00:00Z', avatar: 'https://picsum.photos/seed/provider4/100/100' }, 
    { id: 5, name: 'Cantinho Feliz Babysitting', category: 'Babysitters', rating: 4.9, jobsCompleted: 120, description: 'Cuidado infantil de confiança, com educadoras certificadas, para a sua tranquilidade.', zones: ['Lisboa'], membershipLevel: 'VIP', memberSince: '2022-09-01T18:00:00Z', avatar: 'https://picsum.photos/seed/provider5/100/100' }, 
    { id: 6, name: 'Madeira Mestra Carpintaria', category: 'Carpinteiros', rating: 4.6, jobsCompleted: 75, description: 'Móveis por medida, cozinhas, roupeiros e todo o tipo de reparações em madeira.', zones: ['Braga', 'Guimarães'], membershipLevel: 'Normal', memberSince: '2023-10-05T11:00:00Z', avatar: 'https://picsum.photos/seed/provider6/100/100' }, 
    { id: 7, name: 'Jardim Sempre Verde', category: 'Jardineiros', rating: 4.8, jobsCompleted: 189, description: 'Manutenção de jardins e espaços verdes, sistemas de rega e poda de árvores.', zones: ['Sintra', 'Cascais', 'Oeiras'], membershipLevel: 'Profissional', memberSince: '2021-03-22T07:00:00Z', avatar: 'https://picsum.photos/seed/provider7/100/100' }, 
    { id: 8, name: 'Advocacia Correia Mendes', category: 'Advogados', rating: 4.9, jobsCompleted: 50, description: 'Assessoria jurídica em direito civil, comercial e de família. Primeira consulta informativa.', zones: ['Lisboa', 'Porto'], membershipLevel: 'VIP', memberSince: '2024-05-20T16:00:00Z', avatar: 'https://picsum.photos/seed/provider8/100/100' }, 
    { id: 9, name: 'Web Solutions PT', category: 'Web Developers', rating: 5.0, jobsCompleted: 45, description: 'Criação de websites modernos, lojas online e soluções de marketing digital à medida.', zones: ['Todo o país'], membershipLevel: 'Profissional', memberSince: '2023-08-11T12:00:00Z', avatar: 'https://picsum.photos/seed/provider9/100/100' }, 
    { id: 10, name: 'Mudanças Relâmpago', category: 'Mudanças', rating: 4.7, jobsCompleted: 250, description: 'Serviço completo de mudanças residenciais e empresariais, com embalamento e desmontagem.', zones: ['Todo o país'], membershipLevel: 'Profissional', memberSince: '2020-02-18T13:45:00Z', avatar: 'https://picsum.photos/seed/provider10/100/100' },
];

export const POSTAL_CODE_DATA: PostalCodeData = {
    '1150-023': { freguesia: 'Arroios', concelho: 'Lisboa', distrito: 'Lisboa' }, 
    '1000-001': { freguesia: 'Avenidas Novas', concelho: 'Lisboa', distrito: 'Lisboa' }, 
    '4000-452': { freguesia: 'Cedofeita, Santo Ildefonso, Sé, Miragaia, São Nicolau e Vitória', concelho: 'Porto', distrito: 'Porto' }, 
    '4400-001': { freguesia: 'Santa Marinha e São Pedro da Afurada', concelho: 'Vila Nova de Gaia', distrito: 'Porto' }, 
    '3000-013': { freguesia: 'Sé Nova, Santa Cruz, Almedina e São Bartolomeu', concelho: 'Coimbra', distrito: 'Coimbra' }, 
    '4700-001': { freguesia: 'Braga (Maximinos, Sé e Cividade)', concelho: 'Braga', distrito: 'Braga' }, 
    '8000-001': { freguesia: 'Faro (Sé e São Pedro)', concelho: 'Faro', distrito: 'Faro' }, 
    '2725-001': { freguesia: 'Algueirão-Mem Martins', concelho: 'Sintra', distrito: 'Lisboa' }, 
    '9500-001': { freguesia: 'Ponta Delgada (São Sebastião)', concelho: 'Ponta Delgada', distrito: 'Açores' }, 
    '9000-001': { freguesia: 'Funchal (Sé)', concelho: 'Funchal', distrito: 'Madeira' },
};

export const MAP_MARKER_DATA: MapMarkerData[] = [
    { city: 'Lisboa', lat: 38.7223, lng: -9.1393, service: 'Eletricistas' }, 
    { city: 'Porto', lat: 41.1579, lng: -8.6291, service: 'Canalizadores' }, 
    { city: 'Faro', lat: 37.0194, lng: -7.9304, service: 'Jardineiros' }, 
    { city: 'Coimbra', lat: 40.2033, lng: -8.4103, service: 'Pintores' }, 
    { city: 'Viseu', lat: 40.6575, lng: -7.9138, service: 'Carpinteiros' }, 
    { city: 'Funchal', lat: 32.6669, lng: -16.9085, service: 'Limpeza Doméstica' }, 
    { city: 'Ponta Delgada', lat: 37.7412, lng: -25.6756, service: 'Babysitters' }, 
    { city: 'Braga', lat: 41.5454, lng: -8.4265, service: 'Remodelações' }, 
    { city: 'Aveiro', lat: 40.6443, lng: -8.6455, service: 'Arquitetos' }, 
    { city: 'Évora', lat: 38.5714, lng: -7.9079, service: 'Advogados' }
];

export const PRICING_PLANS: PricingPlan[] = [
    { name: 'Base', price: '15', features: ['Acesso a 3 Orçamentos/mês'], isPopular: false },
    { name: 'Profissional', price: '25', features: ['Acesso a 6 Orçamentos/mês', 'Pode comprar pacotes extra'], isPopular: false },
    { name: 'Profissional Plus', price: '35', features: ['Acesso a 10 Orçamentos/mês', 'Destaque nas pesquisas'], isPopular: true },
    { name: 'VIP', price: '50', features: ['Acesso a 20 Orçamentos/mês', 'Destaque VIP', 'Suporte prioritário'], isPopular: false },
    { name: 'Premium', price: 'Sob Consulta', features: ['Orçamentos ilimitados', 'Apoio Premium e Consultoria', 'Soluções personalizadas'], isPopular: false, isCustom: true },
];

export const PAYMENT_METHODS: PaymentMethod[] = [
    { name: 'MB Way', icon: MbWayIcon },
    { name: 'PayPal', icon: PayPalIcon },
    { name: 'Visa', icon: VisaIcon },
    { name: 'Mastercard', icon: MastercardIcon },
    { name: 'Débito Direto', icon: DirectDebitIcon },
];

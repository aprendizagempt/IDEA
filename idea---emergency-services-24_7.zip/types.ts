
import React from "react";

export interface ServiceCategory {
    name: string;
    icon: React.FC<React.SVGProps<SVGSVGElement>>;
}

export interface Testimonial {
    id: number;
    client: string;
    service: string;
    rating: number;
    comment: string;
    avatar: string;
}

export interface ServiceProvider {
    id: number;
    name: string;
    category: string;
    rating: number;
    jobsCompleted: number;
    description: string;
    zones: string[];
    membershipLevel: 'VIP' | 'Profissional' | 'Normal';
    memberSince: string;
    avatar: string;
}

export interface PostalCodeData {
    [key: string]: {
        freguesia: string;
        concelho: string;
        distrito: string;
    };
}

export interface MapMarkerData {
    city: string;
    lat: number;
    lng: number;
    service: string;
}

export interface PricingPlan {
    name: string;
    price: string;
    features: string[];
    isPopular: boolean;
    isCustom?: boolean;
}

export interface PaymentMethod {
    name: string;
    icon: React.FC<React.SVGProps<SVGSVGElement>>;
}

export interface CurrentUser {
    type: 'client' | 'provider';
    name?: string;
    id?: string;
    profileComplete?: boolean;
}

export interface AIEstimate {
    estimated_cost_min: number;
    estimated_cost_max: number;
    currency: string;
    breakdown: { item: string; cost: string }[];
    notes: string;
}

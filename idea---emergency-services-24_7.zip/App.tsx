
import React, { useState, useEffect } from 'react';
import { Header } from './components/layout/Header';
import { Hero } from './components/sections/Hero';
import { ServiceCategories } from './components/sections/ServiceCategories';
import { HowItWorks } from './components/sections/HowItWorks';
import { ProviderListings } from './components/sections/ProviderListings';
import { QuoteRequest } from './components/sections/QuoteRequest';
import { Testimonials } from './components/sections/Testimonials';
import { AdBanner } from './components/sections/AdBanner';
import { PricingPlans } from './components/sections/PricingPlans';
import { MapSection } from './components/sections/MapSection';
import { AboutUs } from './components/sections/AboutUs';
import { Footer } from './components/layout/Footer';
import { RegistrationModal } from './components/modals/RegistrationModal';
import { LoginModal } from './components/modals/LoginModal';
import { ProviderProfileModal } from './components/modals/ProviderProfileModal';
import { CurrentUser } from './types';

const App: React.FC = () => {
    const [theme, setTheme] = useState('dark');
    const [currentUser, setCurrentUser] = useState<CurrentUser | null>(null);
    const [isRegistrationModalOpen, setRegistrationModalOpen] = useState(false);
    const [isLoginModalOpen, setLoginModalOpen] = useState(false);
    const [isProviderProfileModalOpen, setProviderProfileModalOpen] = useState(false);
    const [preselectedCategory, setPreselectedCategory] = useState('');
    const [preselectedServiceForQuote, setPreselectedServiceForQuote] = useState('');
    const [selectedZoneFromMap, setSelectedZoneFromMap] = useState('');

    useEffect(() => {
        const savedTheme = localStorage.getItem('theme') || 'dark';
        setTheme(savedTheme);
    }, []);

    useEffect(() => {
        if (theme === 'dark') {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
        localStorage.setItem('theme', theme);
    }, [theme]);

    useEffect(() => {
        if (currentUser && currentUser.type === 'provider' && !currentUser.profileComplete) {
            setProviderProfileModalOpen(true);
        }
    }, [currentUser]);

    const toggleTheme = () => setTheme(prevTheme => (prevTheme === 'light' ? 'dark' : 'light'));

    const handleLogin = (user: CurrentUser) => {
        setCurrentUser(user);
        setLoginModalOpen(false);
    };

    const handleLogout = () => setCurrentUser(null);

    const handleSaveProfile = (profileData: { category: string; zones: string; description: string; }) => {
        setCurrentUser(prev => prev ? { ...prev, ...profileData, profileComplete: true } : null);
        console.log("Provider profile saved:", profileData);
    };

    const handleCategorySelection = (categoryName: string) => {
        setPreselectedCategory(categoryName);
        const professionalsSection = document.getElementById('profissionais');
        if (professionalsSection) {
            professionalsSection.scrollIntoView({ behavior: 'smooth' });
        }
    };
    
    const handleRequestQuoteForService = (serviceName: string) => {
        setPreselectedServiceForQuote(serviceName);
         const quoteSection = document.getElementById('pedir-orcamento');
        if (quoteSection) {
            quoteSection.scrollIntoView({ behavior: 'smooth' });
        }
    }


    return (
        <div className="bg-stone-100 dark:bg-slate-900 text-stone-800 dark:text-stone-200 min-h-screen font-sans transition-colors duration-300">
            <Header
                theme={theme}
                toggleTheme={toggleTheme}
                onRegisterClick={() => setRegistrationModalOpen(true)}
                onLoginClick={() => setLoginModalOpen(true)}
                onLogout={handleLogout}
                currentUser={currentUser}
            />
            <main>
                <Hero onRequestQuote={handleRequestQuoteForService} onSearch={handleCategorySelection} />
                <ServiceCategories onServiceSelect={handleCategorySelection} />
                <HowItWorks />
                <ProviderListings
                    preselectedCategory={preselectedCategory}
                    onCategoryClear={() => setPreselectedCategory('')}
                    selectedZoneFromMap={selectedZoneFromMap}
                    onZoneClear={() => setSelectedZoneFromMap('')}
                    onRequestQuote={handleRequestQuoteForService}
                />
                <QuoteRequest
                    preselectedService={preselectedServiceForQuote}
                    onFormInteracted={() => setPreselectedServiceForQuote('')}
                    currentUser={currentUser}
                    onLoginPrompt={() => setLoginModalOpen(true)}
                />
                <Testimonials />
                <AdBanner onRegisterClick={() => setRegistrationModalOpen(true)} />
                <PricingPlans onRegisterClick={() => setRegistrationModalOpen(true)} />
                <MapSection onCitySelect={setSelectedZoneFromMap} onRequestQuote={handleRequestQuoteForService} />
                <AboutUs />
            </main>
            <Footer />
            <RegistrationModal isOpen={isRegistrationModalOpen} onClose={() => setRegistrationModalOpen(false)} />
            <LoginModal isOpen={isLoginModalOpen} onClose={() => setLoginModalOpen(false)} onLogin={handleLogin} />
            <ProviderProfileModal isOpen={isProviderProfileModalOpen} onClose={() => setProviderProfileModalOpen(false)} onSave={handleSaveProfile} />
        </div>
    );
};

export default App;

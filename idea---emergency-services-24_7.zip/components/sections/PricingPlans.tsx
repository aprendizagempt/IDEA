
import React from 'react';
import { PRICING_PLANS, PAYMENT_METHODS } from '../../constants';
import { CheckIcon } from '../icons/CheckIcon';

interface PricingPlansProps {
    onRegisterClick: () => void;
}

export const PricingPlans: React.FC<PricingPlansProps> = ({ onRegisterClick }) => {
    return (
        <section id="planos" className="py-16 sm:py-24 bg-stone-100 dark:bg-slate-800/50">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-extrabold text-stone-900 dark:text-white tracking-tight">Planos de Subscrição para Profissionais</h2>
                    <p className="mt-4 text-lg text-stone-600 dark:text-stone-300 max-w-2xl mx-auto">Escolha o plano que melhor se adapta ao crescimento do seu negócio.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 items-end">
                    {PRICING_PLANS.map(plan => (
                        <div
                            key={plan.name}
                            className={`bg-white dark:bg-slate-800 rounded-lg shadow-lg p-8 text-center flex flex-col relative transition-all duration-300 ${plan.isPopular ? 'border-2 border-blue-600 dark:border-blue-500 scale-105 z-10' : 'border border-transparent'}`}
                        >
                            {plan.isPopular && <div className='absolute -top-4 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-xs font-bold px-4 py-1 rounded-full'>MAIS POPULAR</div>}
                            <h3 className="text-2xl font-bold text-stone-800 dark:text-white">{`Plano ${plan.name}`}</h3>
                            <div className="my-6">
                                {plan.isCustom ? (
                                    <p className="text-3xl font-bold text-stone-900 dark:text-white">{plan.price}</p>
                                ) : (
                                    <p className="text-5xl font-bold text-stone-900 dark:text-white">
                                        €{plan.price}
                                        <span className='text-base font-normal text-stone-500 dark:text-stone-400'>/mês + IVA</span>
                                    </p>
                                )}
                            </div>
                            <ul className="space-y-4 text-stone-600 dark:text-stone-300 flex-grow mb-8">
                                {plan.features.map(feature => (
                                    <li key={feature} className='flex items-center justify-center gap-2'>
                                        <CheckIcon className='w-5 h-5 text-green-500 flex-shrink-0' />
                                        <span>{feature}</span>
                                    </li>
                                ))}
                            </ul>
                            <button
                                onClick={onRegisterClick}
                                className={`w-full py-3 rounded-lg font-semibold transition ${plan.isPopular ? 'bg-blue-600 text-white hover:bg-blue-700' : (plan.isCustom ? 'bg-slate-600 text-white hover:bg-slate-700' : 'bg-stone-200 dark:bg-slate-700 text-stone-800 dark:text-stone-200 hover:bg-stone-300 dark:hover:bg-slate-600')}`}
                            >
                                {plan.isCustom ? 'Contacte-nos' : 'Aderir ao Plano'}
                            </button>
                        </div>
                    ))}
                </div>
                <div className='mt-16 text-center'>
                    <h3 className='text-xl font-semibold text-stone-800 dark:text-white mb-6'>Métodos de Pagamento Aceites</h3>
                    <div className='flex justify-center items-center flex-wrap gap-x-6 gap-y-4'>
                        {PAYMENT_METHODS.map(method => {
                            const Icon = method.icon;
                            return (
                                <div key={method.name} className='flex flex-col items-center gap-2 text-stone-600 dark:text-stone-300'>
                                    <Icon className='h-10' />
                                    <span className='text-sm font-medium'>{method.name}</span>
                                </div>
                            );
                        })}
                    </div>
                </div>
                <div className='mt-12 max-w-4xl mx-auto text-center text-sm text-stone-500 dark:text-stone-400 bg-stone-50 dark:bg-slate-800 p-6 rounded-lg'>
                    <p className='font-bold mb-2'>Nota Importante:</p>
                    <p>Os primeiros 3 meses são grátis, com um período de fidelização de 24 meses. Todos os planos excluem a comissão de serviço cobrada pela plataforma sobre os trabalhos concluídos com sucesso.</p>
                </div>
            </div>
        </section>
    );
};

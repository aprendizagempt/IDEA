
import React, { useEffect, useRef, useState, useCallback } from 'react';
import ReactDOM from 'react-dom/client';
import { MAP_MARKER_DATA } from '../../constants';
import { LocationMarkerIcon } from '../icons/LocationMarkerIcon';
import type { Map, DivIcon, Marker } from 'leaflet';

// Leaflet is a global variable from the CDN script, declare it to satisfy TypeScript
declare const L: any;

interface MapSectionProps {
    onCitySelect: (city: string) => void;
    onRequestQuote: (serviceName: string) => void;
}

const PopupContent: React.FC<{ data: { service: string; city: string }, onButtonClick: () => void }> = ({ data, onButtonClick }) => {
    return (
        <div className='flex flex-col items-center gap-2 p-1 font-sans'>
            <div className='inline-block'>
                <strong className='text-base font-bold text-stone-800 dark:text-white animate-typing overflow-hidden border-r-2 border-blue-600 whitespace-nowrap mx-auto'>
                    {data.service}
                </strong>
            </div>
            <span className='text-sm text-stone-600 dark:text-stone-400'>{data.city}</span>
            <button
                onClick={onButtonClick}
                className='bg-blue-600 text-white px-3 py-1.5 rounded-md text-xs font-semibold hover:bg-blue-700 transition'
            >
                Pedir Orçamento
            </button>
        </div>
    );
};

const CityPopupContent: React.FC<{ city: { name: string }, onButtonClick: () => void }> = ({ city, onButtonClick }) => {
    return (
        <div className='flex flex-col items-center gap-2 p-1 font-sans'>
            <strong className='text-base font-bold text-stone-800 dark:text-white'>{city.name}</strong>
            <button
                onClick={onButtonClick}
                className='bg-blue-600 text-white px-3 py-1.5 rounded-md text-xs font-semibold hover:bg-blue-700 transition mt-2'
            >
                Ver Serviços Disponíveis
            </button>
        </div>
    );
};


export const MapSection: React.FC<MapSectionProps> = ({ onCitySelect, onRequestQuote }) => {
    const mapContainerRef = useRef<HTMLDivElement>(null);
    const mapInstanceRef = useRef<Map | null>(null);
    const blinkingMarkersRef = useRef<Marker[]>([]);
    const userLocationMarkerRef = useRef<Marker | null>(null);
    const selectedCityMarkerRef = useRef<Marker | null>(null);

    const [isLocating, setIsLocating] = useState(false);
    const [userLocationFound, setUserLocationFound] = useState(false);

    const MAJOR_CITIES = [
        { name: 'Lisboa', lat: 38.7223, lng: -9.1393, zoom: 12 },
        { name: 'Porto', lat: 41.1579, lng: -8.6291, zoom: 12 },
        { name: 'Viseu', lat: 40.6575, lng: -7.9138, zoom: 13 },
        { name: 'Beja', lat: 38.0151, lng: -7.8633, zoom: 13 },
        { name: 'Braga', lat: 41.5454, lng: -8.4265, zoom: 12 },
        { name: 'Faro', lat: 37.0194, lng: -7.9304, zoom: 13 }
    ];

    const createInteractivePopup = useCallback((data: { city: string, service: string }, map: Map) => {
        const popupNode = document.createElement('div');
        const root = ReactDOM.createRoot(popupNode);

        const handleButtonClick = () => {
            onRequestQuote(data.service);
            map.closePopup();
        };

        root.render(<PopupContent data={data} onButtonClick={handleButtonClick} />);
        return popupNode;
    }, [onRequestQuote]);

    const addBlinkingMarkers = useCallback((map: Map, markersRef: React.MutableRefObject<Marker[]>) => {
        if (markersRef.current.length > 0) {
            markersRef.current.forEach(m => map.removeLayer(m));
            markersRef.current = [];
        }

        const locations = [...MAP_MARKER_DATA].sort(() => 0.5 - Math.random()).slice(0, 3);

        locations.forEach(data => {
            const blinkingIcon: DivIcon = L.divIcon({
                className: 'blinking-marker',
                html: '',
                iconSize: [24, 24],
                iconAnchor: [12, 12]
            });

            const newMarker = L.marker([data.lat, data.lng], { icon: blinkingIcon }).addTo(map);
            const popupContent = createInteractivePopup(data, map);
            newMarker.bindPopup(popupContent);

            markersRef.current.push(newMarker);
        });
    }, [createInteractivePopup]);

    useEffect(() => {
        if (mapContainerRef.current && !mapInstanceRef.current && typeof L !== 'undefined') {
            const map: Map = L.map(mapContainerRef.current, {
                zoomControl: true,
                scrollWheelZoom: false,
            }).setView([39.5, -8.0], 7);

            L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
                subdomains: 'abcd',
                maxZoom: 20
            }).addTo(map);

            setTimeout(() => map.invalidateSize(), 100);
            mapInstanceRef.current = map;

            addBlinkingMarkers(map, blinkingMarkersRef);
            const intervalId = setInterval(() => addBlinkingMarkers(map, blinkingMarkersRef), 5000);

            return () => {
                clearInterval(intervalId);
                map.remove();
                mapInstanceRef.current = null;
            };
        }
    }, [addBlinkingMarkers]);

    const handleCityClick = (city: { name: string, lat: number, lng: number, zoom: number }) => {
        const map = mapInstanceRef.current;
        if (!map) return;

        if (selectedCityMarkerRef.current) {
            map.removeLayer(selectedCityMarkerRef.current);
        }

        map.flyTo([city.lat, city.lng], city.zoom || 12);

        const popupNode = document.createElement('div');
        const root = ReactDOM.createRoot(popupNode);

        const handleViewServices = () => {
            onCitySelect(city.name);
            document.getElementById('profissionais')?.scrollIntoView({ behavior: 'smooth' });
            map.closePopup();
        };

        root.render(<CityPopupContent city={city} onButtonClick={handleViewServices} />);

        const newMarker = L.marker([city.lat, city.lng]).addTo(map);
        newMarker.bindPopup(popupNode).openPopup();
        selectedCityMarkerRef.current = newMarker;
    };
    
    const handleLocateUser = () => {
        const map = mapInstanceRef.current;
        if (!map || !navigator.geolocation) return;

        setIsLocating(true);
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                map.flyTo([latitude, longitude], 13);

                if (userLocationMarkerRef.current) {
                    map.removeLayer(userLocationMarkerRef.current);
                }

                const newMarker = L.marker([latitude, longitude]).addTo(map)
                    .bindPopup('A sua localização atual.')
                    .openPopup();
                userLocationMarkerRef.current = newMarker;
                setIsLocating(false);
                setUserLocationFound(true);
            },
            (error) => {
                alert("Não foi possível obter a sua localização. Verifique as permissões do seu navegador.");
                setIsLocating(false);
            }
        );
    };

    return (
        <section className="py-16 sm:py-24">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-stone-900 dark:text-white">Presentes em Todo o Território Nacional</h2>
                    <p className="mt-4 text-lg text-stone-600 dark:text-stone-300 max-w-2xl mx-auto">Encontre profissionais perto de si, de norte a sul do país e ilhas.</p>
                </div>
                <div className='grid grid-cols-1 md:grid-cols-3 gap-8 items-start'>
                    <div className='md:col-span-1 space-y-4'>
                        {!userLocationFound && (
                            <button
                                onClick={handleLocateUser}
                                disabled={isLocating}
                                className='w-full text-left p-4 rounded-lg bg-blue-600 text-white shadow-md hover:bg-blue-700 transition-all flex items-center justify-center gap-2 disabled:bg-blue-400 font-semibold'
                            >
                                <LocationMarkerIcon className="w-5 h-5" />
                                {isLocating ? 'A localizar...' : 'Usar a minha localização'}
                            </button>
                        )}
                        <hr className="border-stone-200 dark:border-slate-700" />
                        {MAJOR_CITIES.map(city =>
                            <button
                                key={city.name}
                                onClick={() => handleCityClick(city)}
                                className='w-full text-left p-4 rounded-lg bg-white dark:bg-slate-800 shadow-md hover:bg-blue-50 dark:hover:bg-slate-700/50 hover:shadow-lg transition-all transform hover:scale-105'
                            >
                                <h3 className='font-bold text-lg text-stone-800 dark:text-white'>{city.name}</h3>
                            </button>
                        )}
                    </div>
                    <div className='md:col-span-2'>
                        <div
                            ref={mapContainerRef}
                            className="h-[500px] w-full rounded-lg overflow-hidden shadow-2xl bg-stone-200 dark:bg-slate-700"
                        />
                    </div>
                </div>
            </div>
        </section>
    );
};

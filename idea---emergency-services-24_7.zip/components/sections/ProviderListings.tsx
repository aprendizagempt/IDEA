
import React, { useState, useMemo, useEffect } from 'react';
import { SERVICE_PROVIDERS } from '../../constants';
import { StarIcon } from '../icons/StarIcon';
import { TagIcon } from '../icons/TagIcon';
import { MapPinIcon } from '../icons/MapPinIcon';
import { CalendarDaysIcon } from '../icons/CalendarDaysIcon';
import { UserIcon } from '../icons/UserIcon';
import { CheckBadgeIcon } from '../icons/CheckBadgeIcon';
import { SparklesIcon } from '../icons/SparklesIcon';
import { ChevronDownIcon } from '../icons/ChevronDownIcon';
import { ChevronUpIcon } from '../icons/ChevronUpIcon';
import { ServiceProvider } from '../../types';

interface ProviderListingsProps {
    preselectedCategory: string;
    onCategoryClear: () => void;
    selectedZoneFromMap: string;
    onZoneClear: () => void;
    onRequestQuote: (serviceName: string) => void;
}

const anonymizeName = (name: string) => {
    return name.split(' ').map(word => {
        if (word.length <= 2) return word;
        return word.substring(0, 2) + '*'.repeat(word.length - 2);
    }).join(' ');
};

const formatMemberSince = (dateString: string) => {
    const memberDate = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - memberDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    if (diffDays <= 30) return 'Membro Novo';
    if (diffDays < 365) {
        const months = Math.floor(diffDays / 30);
        return `Membro há ${months} mes${months > 1 ? 'es' : ''}`;
    }
    const years = Math.floor(diffDays / 365);
    return `Membro há ${years} ano${years > 1 ? 's' : ''}`;
};

const MembershipBadge: React.FC<{ level: ServiceProvider['membershipLevel'] }> = ({ level }) => {
    const badgeStyles = {
        VIP: { text: "VIP", icon: SparklesIcon, classes: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300" },
        Profissional: { text: "Profissional", icon: CheckBadgeIcon, classes: "bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300" },
        Normal: { text: "Normal", icon: UserIcon, classes: "bg-stone-100 text-stone-800 dark:bg-slate-700 dark:text-stone-300" },
    };
    const badge = badgeStyles[level] || badgeStyles.Normal;
    const Icon = badge.icon;
    return (
        <div className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium ${badge.classes}`}>
            <Icon className='w-3.5 h-3.5' />
            {badge.text}
        </div>
    );
};

export const ProviderListings: React.FC<ProviderListingsProps> = ({ preselectedCategory, onCategoryClear, selectedZoneFromMap, onZoneClear, onRequestQuote }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedCategory, setSelectedCategory] = useState('');
    const [selectedZone, setSelectedZone] = useState('');
    const [minRating, setMinRating] = useState(0);
    const [isExpanded, setIsExpanded] = useState(false);

    useEffect(() => {
        if (preselectedCategory) {
            setSelectedCategory(preselectedCategory);
            onCategoryClear();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [preselectedCategory]);

    useEffect(() => {
        if (selectedZoneFromMap) {
            setSelectedZone(selectedZoneFromMap);
        }
    }, [selectedZoneFromMap]);

    const availableCategories = useMemo(() => Array.from(new Set(SERVICE_PROVIDERS.map(p => p.category))).sort(), []);
    const availableZones = useMemo(() => Array.from(new Set(SERVICE_PROVIDERS.flatMap(p => p.zones))).sort(), []);

    const filteredProviders = useMemo(() => {
        return SERVICE_PROVIDERS
            .filter(p => !selectedCategory || p.category === selectedCategory)
            .filter(p => !selectedZone || p.zones.includes(selectedZone) || p.zones.includes('Todo o país'))
            .filter(p => minRating <= 0 || p.rating >= minRating)
            .filter(p => {
                if (!searchTerm) return true;
                const term = searchTerm.toLowerCase();
                return p.name.toLowerCase().includes(term) || p.category.toLowerCase().includes(term) || p.description.toLowerCase().includes(term) || p.zones.some(z => z.toLowerCase().includes(term));
            });
    }, [searchTerm, selectedCategory, selectedZone, minRating]);

    const providersToShow = isExpanded ? filteredProviders : filteredProviders.slice(0, 3);

    const handleContact = (providerName: string) => {
        alert(`A sua mensagem foi enviada para ${anonymizeName(providerName)}. Será contactado em breve para finalizar os detalhes.\n\n(Esta é uma demonstração. Nenhuma mensagem real foi enviada.)`);
    };

    return (
        <section id="profissionais" className="py-16 sm:py-24">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-stone-900 dark:text-white">Encontre o Profissional Ideal</h2>
                    <p className="mt-4 text-lg text-stone-600 dark:text-stone-300 max-w-2xl mx-auto">A nossa rede de profissionais é verificada e avaliada para garantir a sua satisfação.</p>
                </div>
                <div className="mb-12 bg-white dark:bg-slate-800/50 p-6 rounded-lg shadow-md grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className="lg:col-span-2">
                        <label htmlFor="search" className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-1">Pesquisar por Palavra-Chave</label>
                        <input type="text" id="search" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Ex: 'urgente', 'reparação', 'Lisboa'..." className="w-full p-3 border border-stone-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:ring-blue-500 focus:border-blue-500" />
                    </div>
                    <div>
                        <label htmlFor="category-filter" className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-1">Categoria</label>
                        <select id="category-filter" value={selectedCategory} onChange={e => setSelectedCategory(e.target.value)} className="w-full p-3 border border-stone-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:ring-blue-500 focus:border-blue-500">
                            <option value="">Todas as Categorias</option>
                            {availableCategories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="zone-filter" className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-1">Zona</label>
                        <select
                            id="zone-filter"
                            value={selectedZone}
                            onChange={e => {
                                setSelectedZone(e.target.value);
                                if (onZoneClear) onZoneClear();
                            }}
                            className="w-full p-3 border border-stone-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:ring-blue-500 focus:border-blue-500"
                        >
                            <option value="">Todas as Zonas</option>
                            {availableZones.map(zone => <option key={zone} value={zone}>{zone}</option>)}
                        </select>
                    </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {filteredProviders.length > 0 ?
                        providersToShow.map(provider => (
                            <div key={provider.id} className="bg-white dark:bg-slate-800 rounded-lg shadow-lg overflow-hidden flex flex-col transform hover:-translate-y-2 transition-transform duration-300">
                                <div className="p-6">
                                    <div className="flex items-start justify-between mb-4">
                                        <div className="flex items-start gap-4">
                                            <img src={provider.avatar} alt={`Avatar de ${provider.name}`} className="w-16 h-16 rounded-full border-4 border-stone-200 dark:border-slate-700 object-cover" />
                                            <div>
                                                <h3 className="font-bold text-lg text-stone-800 dark:text-white">{anonymizeName(provider.name)}</h3>
                                                <div className="flex items-center space-x-1 mt-1">
                                                    <StarIcon className="w-5 h-5 text-yellow-400" />
                                                    <span className="font-bold text-stone-700 dark:text-stone-200">{provider.rating.toFixed(1)}</span>
                                                    <span className="text-sm text-stone-500 dark:text-stone-400">({provider.jobsCompleted})</span>
                                                </div>
                                            </div>
                                        </div>
                                        <MembershipBadge level={provider.membershipLevel} />
                                    </div>
                                    <p className="text-stone-600 dark:text-stone-300 text-sm mb-4">{provider.description}</p>
                                    <div className='space-y-3 text-sm'>
                                        <div className='flex items-center gap-2 text-stone-600 dark:text-stone-400'><TagIcon className='w-4 h-4 text-stone-400 dark:text-stone-500' /><strong className='text-stone-700 dark:text-stone-300'>Categoria:</strong> {provider.category}</div>
                                        <div className='flex items-center gap-2 text-stone-600 dark:text-stone-400'><MapPinIcon className='w-4 h-4 text-stone-400 dark:text-stone-500' /><strong className='text-stone-700 dark:text-stone-300'>Zonas:</strong> {provider.zones.join(', ')}</div>
                                        <div className='flex items-center gap-2 text-stone-600 dark:text-stone-400'><CalendarDaysIcon className='w-4 h-4 text-stone-400 dark:text-stone-500' /><strong className='text-stone-700 dark:text-stone-300'>Membro:</strong> {formatMemberSince(provider.memberSince)}</div>
                                    </div>
                                </div>
                                <div className="mt-auto p-4 bg-stone-50 dark:bg-slate-800/50 flex gap-2">
                                    <button onClick={() => onRequestQuote(provider.category)} className="flex-1 text-center bg-blue-600 text-white px-4 py-2 rounded-md font-semibold hover:bg-blue-700 transition-colors text-sm">Pedir Orçamento</button>
                                    <button onClick={() => handleContact(provider.name)} className="flex-1 text-center bg-stone-200 dark:bg-slate-700 text-stone-800 dark:text-stone-200 px-4 py-2 rounded-md font-semibold hover:bg-stone-300 dark:hover:bg-slate-600 transition-colors text-sm">Contactar</button>
                                </div>
                            </div>
                        ))
                        : (
                            <div className="col-span-full text-center py-12">
                                <h3 className="text-xl font-semibold text-stone-700 dark:text-stone-300">Nenhum prestador encontrado</h3>
                                <p className="text-stone-500 dark:text-stone-400 mt-2">Tente ajustar os seus filtros de pesquisa.</p>
                            </div>
                        )
                    }
                </div>
                {filteredProviders.length > 3 && (
                    <div className="text-center mt-12">
                        <button
                            onClick={() => setIsExpanded(!isExpanded)}
                            className="bg-stone-200 dark:bg-slate-700 text-stone-800 dark:text-stone-200 px-6 py-3 rounded-md font-semibold hover:bg-stone-300 dark:hover:bg-slate-600 transition-colors flex items-center gap-2 mx-auto"
                        >
                            {isExpanded ? 'Ver Menos' : 'Ver Mais Profissionais'}
                            {isExpanded ? <ChevronUpIcon className="w-5 h-5" /> : <ChevronDownIcon className="w-5 h-5" />}
                        </button>
                    </div>
                )}
            </div>
        </section>
    );
};

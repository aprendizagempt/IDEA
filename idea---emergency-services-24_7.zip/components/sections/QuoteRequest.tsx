
import React, { useState, useEffect, useRef } from 'react';
import { ALL_SERVICES, POSTAL_CODE_DATA } from '../../constants';
import { getAiEstimate } from '../../services/geminiService';
import { AIEstimate, CurrentUser } from '../../types';
import { Spinner } from '../ui/Spinner';

interface QuoteRequestProps {
    preselectedService: string;
    onFormInteracted: () => void;
    currentUser: CurrentUser | null;
    onLoginPrompt: () => void;
}

export const QuoteRequest: React.FC<QuoteRequestProps> = ({ preselectedService, onFormInteracted, currentUser, onLoginPrompt }) => {
    const [formData, setFormData] = useState({ service: '', urgency: 'normal', description: '', location: '' });
    const [estimate, setEstimate] = useState<AIEstimate | null>(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [postalCodeDetails, setPostalCodeDetails] = useState<{ freguesia: string; concelho: string; } | null>(null);
    const [postalCodeLoading, setPostalCodeLoading] = useState(false);
    const [postalCodeError, setPostalCodeError] = useState<string | null>(null);
    const debounceTimeoutRef = useRef<number | null>(null);

    useEffect(() => {
        if (preselectedService) {
            setFormData(prev => ({ ...prev, service: preselectedService }));
            onFormInteracted();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [preselectedService]);

    useEffect(() => {
        const postalCode = formData.location.trim();
        if (debounceTimeoutRef.current) {
            clearTimeout(debounceTimeoutRef.current);
        }

        if (/^\d{4}-\d{3}$/.test(postalCode)) {
            setPostalCodeLoading(true);
            setPostalCodeError(null);
            setPostalCodeDetails(null);

            debounceTimeoutRef.current = window.setTimeout(() => {
                const details = POSTAL_CODE_DATA[postalCode];
                if (details) {
                    setPostalCodeDetails(details);
                    setPostalCodeError(null);
                } else {
                    setPostalCodeError('Código Postal não encontrado.');
                    setPostalCodeDetails(null);
                }
                setPostalCodeLoading(false);
            }, 300);
        } else {
            setPostalCodeDetails(null);
            setPostalCodeError(null);
            setPostalCodeLoading(false);
        }

        return () => {
            if (debounceTimeoutRef.current) {
                clearTimeout(debounceTimeoutRef.current);
            }
        };
    }, [formData.location]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleFinalSubmit = () => {
        console.log("Final submission data:", formData);
        setIsSubmitted(true);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!currentUser) {
            onLoginPrompt();
            return;
        }

        setLoading(true);
        setError(null);
        setEstimate(null);
        setIsSubmitted(false);

        try {
            const detailedLocation = postalCodeDetails
                ? `${postalCodeDetails.freguesia}, ${postalCodeDetails.concelho}`
                : formData.location;
            const submissionData = { ...formData, location: detailedLocation };
            const result = await getAiEstimate(submissionData);
            setEstimate(result);
        } catch (err: any) {
            setError(err.message || "Não foi possível obter uma estimativa. Por favor, tente novamente mais tarde.");
        } finally {
            setLoading(false);
        }
    };

    const getButtonText = () => {
        if (loading) return <Spinner />;
        if (!currentUser) return 'Fazer Login para Obter Estimativa';
        return 'Obter Estimativa Grátis';
    };

    if (isSubmitted) {
        return (
            <section id="pedir-orcamento" className="bg-stone-100 dark:bg-slate-800 py-16 sm:py-24">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
                    <h2 className="text-3xl md:text-4xl font-bold text-stone-900 dark:text-white mb-4">Pedido Enviado com Sucesso!</h2>
                    <p className="text-lg text-stone-600 dark:text-stone-300 max-w-2xl mx-auto">
                        O seu pedido para <span className="font-semibold text-blue-600">{formData.service}</span> foi enviado para os profissionais na sua área. Irá começar a receber orçamentos em breve na sua área de cliente.
                    </p>
                </div>
            </section>
        );
    }

    return (
        <section id="pedir-orcamento" className="bg-stone-100 dark:bg-slate-800 py-16 sm:py-24">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-stone-900 dark:text-white">Peça um Orçamento Grátis</h2>
                    <p className="mt-4 text-lg text-stone-600 dark:text-stone-300 max-w-2xl mx-auto">Descreva o que precisa e receba uma estimativa de custos instantânea. Depois, envie o seu pedido aos nossos profissionais para receber propostas competitivas.</p>
                </div>
                <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-start">
                    <form onSubmit={handleSubmit} className="space-y-6 bg-stone-50 dark:bg-slate-800/50 p-8 rounded-lg">
                        <div>
                            <label htmlFor="service" className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-1">Tipo de Serviço</label>
                            <select id="service" name="service" value={formData.service} onChange={handleChange} required className="w-full p-3 border border-stone-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:ring-blue-500 focus:border-blue-500">
                                <option value="">Selecione um serviço</option>
                                {ALL_SERVICES.map(s => <option key={s} value={s}>{s}</option>)}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="urgency" className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-1">Urgência</label>
                            <select id="urgency" name="urgency" value={formData.urgency} onChange={handleChange} required className="w-full p-3 border border-stone-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:ring-blue-500 focus:border-blue-500">
                                <option value="normal">Agendamento Normal</option>
                                <option value="hoje">Hoje</option>
                                <option value="urgente">Urgente (Próximas horas)</option>
                            </select>
                        </div>
                        <div>
                            <label htmlFor="location" className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-1">Localização (Código Postal)</label>
                            <div className='relative'>
                                <input type="text" id="location" name="location" value={formData.location} onChange={handleChange} required className="w-full p-3 border border-stone-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:ring-blue-500 focus:border-blue-500" placeholder="Ex: 1150-023" />
                                {postalCodeLoading && <div className='absolute top-1/2 right-3 -translate-y-1/2'><div className='animate-spin rounded-full h-5 w-5 border-b-2 border-blue-500' /></div>}
                            </div>
                            <div className='mt-2 text-sm h-5'>
                                {postalCodeError && <p className='text-red-500 animate-fade-in'>{postalCodeError}</p>}
                                {postalCodeDetails && <p className='text-green-600 dark:text-green-400 font-semibold animate-fade-in'>{`${postalCodeDetails.freguesia}, ${postalCodeDetails.concelho}`}</p>}
                            </div>
                        </div>
                        <div>
                            <label htmlFor="description" className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-1">Descrição Detalhada</label>
                            <textarea id="description" name="description" value={formData.description} onChange={handleChange} required rows={5} className="w-full p-3 border border-stone-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:ring-blue-500 focus:border-blue-500" placeholder="Ex: Torneira da cozinha a pingar constantemente. Preciso de reparação ou substituição." />
                        </div>
                        <div>
                            <button type="submit" disabled={loading} className="w-full bg-slate-600 text-white font-bold py-3 px-4 rounded-md hover:bg-slate-700 disabled:bg-stone-400 disabled:cursor-not-allowed transition-colors flex justify-center items-center h-12">
                                {getButtonText()}
                            </button>
                        </div>
                    </form>
                    <div className="bg-stone-50 dark:bg-slate-900/50 p-8 rounded-lg h-full flex flex-col">
                        <h3 className="text-2xl font-bold mb-4 text-stone-900 dark:text-white">Resultado</h3>
                        <div className="flex-grow">
                            {loading && <p className="text-center text-stone-500 dark:text-stone-400">A calcular... Por favor, aguarde.</p>}
                            {error && <div className="bg-red-100 dark:bg-red-900/50 border-l-4 border-red-500 text-red-700 dark:text-red-300 p-4 rounded-md"><p className="font-bold">Erro</p><p>{error}</p></div>}
                            {estimate && (
                                <div className="space-y-4 animate-fade-in">
                                    <div className="bg-blue-50 dark:bg-blue-900/50 text-center p-6 rounded-lg">
                                        <p className="text-sm text-blue-800 dark:text-blue-200">Preço Estimado por IA</p>
                                        <p className="text-3xl sm:text-4xl font-bold text-blue-600 dark:text-blue-400">{`${estimate.estimated_cost_min.toFixed(2)} - ${estimate.estimated_cost_max.toFixed(2)} ${estimate.currency}`}</p>
                                    </div>
                                    <div>
                                        <h4 className="font-semibold mb-2 text-stone-800 dark:text-stone-100">Desagregação de Custos:</h4>
                                        <ul className="list-disc list-inside space-y-1 text-stone-600 dark:text-stone-300">
                                            {estimate.breakdown.map((item, index) => <li key={index}><strong>{`${item.item}: `}</strong>{item.cost}</li>)}
                                        </ul>
                                    </div>
                                    <div>
                                        <h4 className="font-semibold mb-2 text-stone-800 dark:text-stone-100">Notas da IA:</h4>
                                        <p className="text-sm text-stone-500 dark:text-stone-400 italic">{estimate.notes}</p>
                                    </div>
                                </div>
                            )}
                            {!loading && !estimate && !error && (
                                <div className="text-center text-stone-500 dark:text-stone-400 h-full flex flex-col items-center justify-center">
                                    <p>Preencha o formulário para receber uma estimativa de preço instantânea.</p>
                                    <p className="text-xs mt-2">*Esta é uma estimativa e não um orçamento final.</p>
                                </div>
                            )}
                        </div>
                        {estimate && (
                            <div className="mt-6">
                                <button onClick={handleFinalSubmit} className="w-full bg-blue-600 text-white font-bold py-3 px-4 rounded-md hover:bg-blue-700 transition-colors">
                                    2. Enviar Pedido e Receber Orçamentos
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </section>
    );
};


import React, { useState } from 'react';
import { SERVICE_CATEGORIES } from '../../constants';
import { ChevronDownIcon } from '../icons/ChevronDownIcon';
import { ChevronUpIcon } from '../icons/ChevronUpIcon';

interface ServiceCategoriesProps {
    onServiceSelect: (serviceName: string) => void;
}

export const ServiceCategories: React.FC<ServiceCategoriesProps> = ({ onServiceSelect }) => {
    const [isExpanded, setIsExpanded] = useState(false);
    const visibleCategories = isExpanded ? SERVICE_CATEGORIES : SERVICE_CATEGORIES.slice(0, 12);

    return (
        <section id="serviços" className="py-16 sm:py-24">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-stone-900 dark:text-white">Tudo o que precisa, num só lugar</h2>
                    <p className="mt-4 text-lg text-stone-600 dark:text-stone-300 max-w-2xl mx-auto">Explore a nossa vasta gama de serviços profissionais disponíveis 24/7.</p>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-6">
                    {visibleCategories.map((category) => {
                        const IconComponent = category.icon;
                        return (
                            <button
                                key={category.name}
                                onClick={() => onServiceSelect(category.name)}
                                className="group flex flex-col items-center justify-center p-6 bg-white dark:bg-slate-800 rounded-lg shadow-md hover:shadow-xl hover:-translate-y-2 transition-all duration-300 cursor-pointer text-center w-full"
                            >
                                <div className="text-blue-600 dark:text-blue-500 mb-4 transition-transform duration-300 group-hover:scale-110">
                                    <IconComponent className="w-8 h-8" />
                                </div>
                                <h3 className="text-base font-semibold text-stone-800 dark:text-stone-200">{category.name}</h3>
                            </button>
                        )
                    })}
                </div>
                <div className="text-center mt-12">
                    <button onClick={() => setIsExpanded(!isExpanded)} className="bg-stone-200 dark:bg-slate-700 text-stone-800 dark:text-stone-200 px-6 py-3 rounded-md font-semibold hover:bg-stone-300 dark:hover:bg-slate-600 transition-colors flex items-center gap-2 mx-auto">
                        {isExpanded ? 'Mostrar menos serviços' : 'Mostrar mais serviços'}
                        {isExpanded ? <ChevronUpIcon className="w-5 h-5" /> : <ChevronDownIcon className="w-5 h-5" />}
                    </button>
                </div>
            </div>
        </section>
    );
};

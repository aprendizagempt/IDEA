
import React from 'react';

export const AboutUs: React.FC = () => {
    return (
        <section id="quem-somos" className="bg-white dark:bg-slate-800 py-16 sm:py-24">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                    <div>
                        <h2 className="text-3xl md:text-4xl font-bold text-stone-900 dark:text-white mb-4">Quem Somos</h2>
                        <p className="text-lg text-stone-600 dark:text-stone-300 mb-4">
                            A <span className="font-bold text-blue-600 dark:text-blue-500">IDEA</span> nasceu da necessidade de simplificar a busca por serviços de confiança em Portugal. A nossa missão é conectar clientes a profissionais qualificados de forma rápida, transparente e segura, 24 horas por dia, 7 dias por semana.
                        </p>
                        <p className="text-stone-600 dark:text-stone-300">
                            Acreditamos que todos merecem um serviço de qualidade, seja para uma emergência ou para um projeto planeado. Com um sistema de verificação rigoroso e avaliações de clientes, garantimos que encontra sempre o profissional certo para o trabalho.
                        </p>
                    </div>
                    <div>
                        <img src="https://picsum.photos/seed/office/600/400" alt="Equipa da IDEA a trabalhar" className="rounded-lg shadow-xl" />
                    </div>
                </div>
            </div>
        </section>
    );
};


import React from 'react';

interface AdBannerProps {
    onRegisterClick: () => void;
}

export const AdBanner: React.FC<AdBannerProps> = ({ onRegisterClick }) => {
    return (
        <section className="py-12 bg-stone-100 dark:bg-slate-800/50">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="bg-gradient-to-r from-blue-600 to-indigo-700 dark:from-blue-700 dark:to-indigo-800 rounded-lg shadow-xl p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-8">
                    <div className="text-white text-center md:text-left">
                        <h2 className="text-3xl font-bold">É um Profissional ou Empresa?</h2>
                        <p className="mt-2 text-lg opacity-90 max-w-2xl">Aumente a sua visibilidade e alcance milhares de novos clientes. Junte-se à nossa rede.</p>
                    </div>
                    <div className="flex-shrink-0">
                        <button onClick={onRegisterClick} className="bg-white text-blue-700 font-bold py-3 px-8 rounded-full hover:bg-slate-100 transition-transform hover:scale-105 shadow-md">
                            Registar Agora
                        </button>
                    </div>
                </div>
            </div>
        </section>
    );
};

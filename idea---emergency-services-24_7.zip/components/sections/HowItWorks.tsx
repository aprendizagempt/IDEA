
import React from 'react';

const NumberStep: React.FC<{ number: string; title: string; children: React.ReactNode }> = ({ number, title, children }) => (
    <div className="flex">
        <div className="flex flex-col items-center mr-4">
            <div>
                <div className="flex items-center justify-center w-10 h-10 border rounded-full bg-blue-600 text-white font-bold">{number}</div>
            </div>
            <div className="w-px h-full bg-stone-300 dark:bg-slate-600" />
        </div>
        <div className="pb-8">
            <p className="mb-2 text-xl font-bold text-stone-900 dark:text-white">{title}</p>
            <p className="text-stone-600 dark:text-stone-300">{children}</p>
        </div>
    </div>
);

const LastNumberStep: React.FC<{ number: string; title: string; children: React.ReactNode }> = ({ number, title, children }) => (
     <div className="flex">
        <div className="flex flex-col items-center mr-4">
            <div>
                <div className="flex items-center justify-center w-10 h-10 border rounded-full bg-blue-600 text-white font-bold">{number}</div>
            </div>
        </div>
        <div className="pb-8">
            <p className="mb-2 text-xl font-bold text-stone-900 dark:text-white">{title}</p>
            <p className="text-stone-600 dark:text-stone-300">{children}</p>
        </div>
    </div>
)

export const HowItWorks: React.FC = () => {
    return (
        <section id="como-funciona" className="py-16 sm:py-24 bg-stone-100 dark:bg-slate-800/50">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-stone-900 dark:text-white">Como Funciona? Simples e Transparente.</h2>
                    <p className="mt-4 text-lg text-stone-600 dark:text-stone-300 max-w-2xl mx-auto">Siga estes 3 passos para resolver o seu problema de forma rápida e eficiente.</p>
                </div>
                <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                    <div className="lg:col-span-2">
                        <h3 className="text-2xl font-semibold mb-6 text-stone-800 dark:text-stone-100">Para Clientes</h3>
                        <NumberStep number="1" title="Descreva o Serviço">
                            Preencha o nosso formulário detalhando o que precisa. O pedido é anónimo e será enviado aos profissionais qualificados na sua área.
                        </NumberStep>
                        <NumberStep number="2" title="Receba Vários Orçamentos">
                            Os profissionais interessados enviam as suas propostas. O que fizer o preço mais competitivo e tiver a melhor avaliação, fica com o trabalho.
                        </NumberStep>
                        <LastNumberStep number="3" title="Escolha e Pague com Segurança">
                             Aceite o orçamento, combine os detalhes e, após a conclusão do serviço, pague através da nossa plataforma segura. Nós garantimos que o prestador só recebe após a sua confirmação.
                        </LastNumberStep>
                    </div>
                    <div className="bg-white dark:bg-slate-800 p-8 rounded-lg shadow-lg">
                        <h3 className="text-2xl font-semibold mb-6 text-stone-800 dark:text-stone-100">Para Prestadores</h3>
                        <div className="space-y-6">
                            <div>
                                <h4 className="font-bold text-lg text-stone-900 dark:text-white">Registo e Mensalidade</h4>
                                <p className="text-stone-600 dark:text-stone-300 mt-1">Os primeiros <span className="font-semibold text-blue-600 dark:text-blue-400">3 meses são grátis</span>. Após o período de teste, a subscrição é de apenas <span className="font-semibold">15€/mês (+IVA)</span> para acesso ilimitado a pedidos de clientes.</p>
                            </div>
                            <div>
                                <h4 className="font-bold text-lg text-stone-900 dark:text-white">Comissões de Serviço</h4>
                                <p className="text-stone-600 dark:text-stone-300 mt-1">Cobramos uma comissão de <span className="font-semibold">10% a 15% (+IVA)</span> apenas sobre os trabalhos que concluir com sucesso através da plataforma. Sem trabalho, sem custos.</p>
                            </div>
                            <div>
                                <h4 className="font-bold text-lg text-stone-900 dark:text-white">Pagamento Garantido</h4>
                                <p className="text-stone-600 dark:text-stone-300 mt-1">O cliente paga à plataforma no momento da adjudicação. O valor é libertado para si assim que o serviço é marcado como concluído pelo cliente, garantindo total segurança.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

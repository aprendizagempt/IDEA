
import React, { useState } from 'react';
import { BoltIcon } from '../icons/BoltIcon';
import { CheckBadgeIcon } from '../icons/CheckBadgeIcon';
import { CreditCardIcon } from '../icons/CreditCardIcon';
import { GlobeAltIcon } from '../icons/GlobeAltIcon';
import { MagnifyingGlassIcon } from '../icons/MagnifyingGlassIcon';

interface HeroProps {
    onRequestQuote: (service: string) => void;
    onSearch: (service: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onRequestQuote, onSearch }) => {
    const [searchTerm, setSearchTerm] = useState('');

    const features = [
        { text: 'Resposta em minutos', icon: <BoltIcon className="w-5 h-5 text-blue-500" /> },
        { text: 'Profissionais verificados', icon: <CheckBadgeIcon className="w-5 h-5 text-blue-500" /> },
        { text: 'Pagamento após serviço', icon: <CreditCardIcon className="w-5 h-5 text-blue-500" /> },
        { text: 'Disponível em todo o país', icon: <GlobeAltIcon className="w-5 h-5 text-blue-500" /> },
    ];

    const handleSearch = () => {
        if (searchTerm.trim()) {
            onSearch(searchTerm.trim());
        }
    };
    
    const handleRequestQuote = () => {
         if (searchTerm.trim()) {
            onRequestQuote(searchTerm.trim());
        } else {
             const quoteSection = document.getElementById('pedir-orcamento');
             if (quoteSection) {
                quoteSection.scrollIntoView({ behavior: 'smooth' });
             }
        }
    }

    return (
        <section className="py-20 lg:py-32 bg-stone-50 dark:bg-slate-800/50 relative overflow-hidden">
            <div className="absolute inset-0 bg-cover bg-center bg-[url('https://picsum.photos/seed/lisbon/1920/1080')] opacity-10 dark:opacity-5" />
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-stone-900 dark:text-white leading-tight mb-4">
                    A solução para os seus problemas, <span className="text-blue-600 dark:text-blue-500">agora</span>.
                </h1>
                <p className="max-w-3xl mx-auto text-lg text-stone-600 dark:text-stone-300 mb-8">
                    Encontre profissionais qualificados para qualquer serviço, a qualquer hora. Desde uma reparação urgente a um projeto planeado.
                </p>
                <div className="max-w-4xl mx-auto bg-white dark:bg-slate-800 p-4 rounded-lg shadow-lg flex flex-col md:flex-row items-center gap-4">
                    <div className="relative flex-grow w-full">
                        <MagnifyingGlassIcon className="w-5 h-5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                            type="text"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            placeholder="Qual serviço precisa? Ex: 'eletricista'"
                            className="w-full pl-10 pr-4 py-3 border-2 border-transparent focus:border-blue-500 bg-stone-100 dark:bg-slate-700 rounded-md focus:outline-none transition"
                        />
                    </div>
                    <div className="flex items-center gap-2 w-full md:w-auto">
                        <button onClick={handleSearch} className="bg-blue-600 text-white font-semibold px-8 py-3 rounded-md hover:bg-blue-700 transition-transform hover:scale-105 w-full md:w-auto">
                            Procurar
                        </button>
                        <button onClick={handleRequestQuote} className="bg-stone-200 dark:bg-slate-700 font-semibold px-8 py-3 rounded-md hover:bg-stone-300 dark:hover:bg-slate-600 transition-transform hover:scale-105 w-full md:w-auto">
                            Orçamento Grátis
                        </button>
                    </div>
                </div>
                <div className="mt-8 flex flex-wrap justify-center items-center gap-x-6 gap-y-2">
                    {features.map((feature, index) => (
                        <div key={index} className="flex items-center gap-2 text-sm text-stone-600 dark:text-stone-400">
                            {feature.icon}
                            <span>{feature.text}</span>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};


import React from 'react';
import { TESTIMONIALS } from '../../constants';
import { StarIcon } from '../icons/StarIcon';

export const Testimonials: React.FC = () => {
    return (
        <section className="bg-stone-100 dark:bg-slate-800/50 py-16 sm:py-24">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-stone-900 dark:text-white">Avaliações de Clientes Satisfeitos</h2>
                    <p className="mt-4 text-lg text-stone-600 dark:text-stone-300 max-w-2xl mx-auto">Veja o que os nossos clientes dizem sobre os profissionais da nossa plataforma.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {TESTIMONIALS.map(review => (
                        <div key={review.id} className="bg-white dark:bg-slate-800 p-8 rounded-lg shadow-lg">
                            <div className="flex items-start">
                                <img src={review.avatar} alt="Avatar do cliente" className="w-16 h-16 rounded-full mr-6 object-cover" />
                                <div className="flex-1">
                                    <div className="flex items-center justify-between mb-2 flex-wrap">
                                        <div>
                                            <h4 className="font-bold text-lg text-stone-800 dark:text-white">{review.client}</h4>
                                            <p className="text-sm text-stone-500 dark:text-stone-400">{review.service}</p>
                                        </div>
                                        <div className="flex items-center space-x-1">
                                            {[...Array(5)].map((_, i) => (
                                                <StarIcon key={i} className={`w-5 h-5 ${i < Math.round(review.rating) ? 'text-yellow-400' : 'text-stone-300 dark:text-slate-600'}`} />
                                            ))}
                                            <span className="font-bold text-stone-700 dark:text-stone-200 ml-2">{review.rating.toFixed(1)}</span>
                                        </div>
                                    </div>
                                    <blockquote className="text-stone-600 dark:text-stone-300 italic border-l-4 border-blue-200 dark:border-blue-800 pl-4 py-2">
                                        "{review.comment}"
                                    </blockquote>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

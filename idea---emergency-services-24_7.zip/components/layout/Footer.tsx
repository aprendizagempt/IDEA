
import React from 'react';

export const Footer: React.FC = () => {
    return (
        <footer id="contactos" className="bg-slate-800 dark:bg-slate-950 text-slate-300">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                    <div className="md:col-span-2">
                        <h3 className="text-xl font-bold text-white mb-2">IDEA</h3>
                        <p className="text-slate-400 mb-4">Serviços de Urgência 24/7 em Portugal.</p>
                        <p className="text-sm text-slate-500">A sua plataforma de confiança para encontrar profissionais verificados para qualquer necessidade, a qualquer momento.</p>
                    </div>
                    <div>
                        <h4 className="font-semibold text-white mb-4">Links Rápidos</h4>
                        <ul className="space-y-2">
                            <li><a href="#quem-somos" className="hover:text-blue-400 transition-colors">Quem Somos</a></li>
                            <li><a href="#serviços" className="hover:text-blue-400 transition-colors">Serviços</a></li>
                            <li><a href="#planos" className="hover:text-blue-400 transition-colors">Registo de Profissional</a></li>
                            <li><a href="#" className="hover:text-blue-400 transition-colors">Termos e Condições</a></li>
                        </ul>
                    </div>
                    <div>
                        <h4 className="font-semibold text-white mb-4">Contactos</h4>
                        <ul className="space-y-2 text-slate-400">
                            <li className="flex items-start">
                                <span className="font-semibold text-slate-200 mr-2">Endereço:</span>
                                <span>Avenida da Liberdade, Lisboa, Portugal</span>
                            </li>
                            <li className="flex items-start">
                                <span className="font-semibold text-slate-200 mr-2">Apoio:</span>
                                <a href="mailto:apoio@idea.pt" className="hover:text-blue-400">apoio@idea.pt</a>
                            </li>
                            <li className="flex items-start">
                                <span className="font-semibold text-slate-200 mr-2">Telefone:</span>
                                <a href="tel:+351210123456" className="hover:text-blue-400">+351 210 123 456</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div className="mt-8 pt-8 border-t border-slate-700 text-center text-sm text-slate-500">
                    <p>© {new Date().getFullYear()} IDEA - Serviços de Urgência. Todos os direitos reservados.</p>
                </div>
            </div>
        </footer>
    );
};

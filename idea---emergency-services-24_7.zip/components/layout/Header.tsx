
import React from 'react';
import { SunIcon } from '../icons/SunIcon';
import { MoonIcon } from '../icons/MoonIcon';
import { GlobeAltIcon } from '../icons/GlobeAltIcon';
import { CurrentUser } from '../../types';

interface HeaderProps {
    theme: string;
    toggleTheme: () => void;
    onRegisterClick: () => void;
    onLoginClick: () => void;
    onLogout: () => void;
    currentUser: CurrentUser | null;
}

export const Header: React.FC<HeaderProps> = ({ theme, toggleTheme, onRegisterClick, onLoginClick, onLogout, currentUser }) => {
    const navLinks = [
        { name: 'Quem Somos', href: '#quem-somos' },
        { name: 'Serviços', href: '#serviços' },
        { name: 'Profissionais', href: '#profissionais' },
        { name: 'Planos', href: '#planos' },
        { name: 'Como Funciona', href: '#como-funciona' },
        { name: 'Contactos', href: '#contactos' },
    ];

    return (
        <header className="sticky top-0 z-40 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm shadow-md">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-20">
                    <div className="flex items-center space-x-4">
                        <a href="#" className="text-3xl font-bold text-blue-600 dark:text-blue-500">IDEA</a>
                        <p className="hidden md:block text-sm text-stone-500 dark:text-stone-400 mt-1">Serviços de Urgência 24/7</p>
                    </div>
                    <nav className="hidden lg:flex items-center space-x-8">
                        {navLinks.map(link => (
                            <a key={link.name} href={link.href} className="text-stone-600 dark:text-stone-300 hover:text-blue-600 dark:hover:text-blue-500 transition-colors font-medium">
                                {link.name}
                            </a>
                        ))}
                    </nav>
                    <div className="flex items-center space-x-4">
                        {currentUser ? (
                            <div className="flex items-center space-x-4">
                                <span className='text-sm font-medium hidden sm:inline'>Bem-vindo, {currentUser.type === 'client' ? currentUser.name : currentUser.id}</span>
                                <button onClick={onLogout} className="bg-stone-200 dark:bg-slate-700 text-stone-800 dark:text-stone-200 px-4 py-2 rounded-md font-semibold hover:bg-stone-300 dark:hover:bg-slate-600 transition-colors text-sm">
                                    Logout
                                </button>
                            </div>
                        ) : (
                            <>
                                <button onClick={onLoginClick} className="hidden sm:inline-block text-stone-600 dark:text-stone-300 hover:text-blue-600 dark:hover:text-blue-500 transition-colors font-semibold text-sm">
                                    Login
                                </button>
                                <button onClick={onRegisterClick} className="hidden sm:inline-block bg-blue-600 text-white px-4 py-2 rounded-md font-semibold hover:bg-blue-700 transition-colors text-sm">
                                    Registar
                                </button>
                            </>
                        )}
                        <button 
                            title="Translate"
                            className="p-2 rounded-full text-stone-500 dark:text-stone-400 hover:bg-stone-200 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-slate-900" 
                            aria-label="Translate website"
                        >
                            <GlobeAltIcon className="h-6 w-6" />
                        </button>
                        <button 
                            onClick={toggleTheme} 
                            className="p-2 rounded-full text-stone-500 dark:text-stone-400 hover:bg-stone-200 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-slate-900" 
                            aria-label="Toggle theme"
                        >
                            {theme === 'light' ? <MoonIcon className="h-6 w-6" /> : <SunIcon className="h-6 w-6" />}
                        </button>
                    </div>
                </div>
            </div>
        </header>
    );
};

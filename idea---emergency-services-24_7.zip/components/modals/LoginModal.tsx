
import React, { useState } from 'react';
import { Modal } from './Modal';
import { FormInput } from '../ui/FormInput';
import { CurrentUser } from '../../types';

interface LoginModalProps {
    isOpen: boolean;
    onClose: () => void;
    onLogin: (user: CurrentUser) => void;
}

const ClientLoginForm: React.FC<{ onBack: () => void; onLogin: LoginModalProps['onLogin'] }> = ({ onBack, onLogin }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSimulatedLogin = (e: React.FormEvent) => {
        e.preventDefault();
        if (email && password) {
            onLogin({ type: 'client', name: email.split('@')[0] });
        }
    };

    return (
        <form onSubmit={handleSimulatedLogin} className='space-y-4'>
            <h2 className="text-2xl font-bold text-center text-stone-800 dark:text-white">Login de Cliente</h2>
            <FormInput name="email" placeholder="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            <FormInput name="password" placeholder="Palavra-passe" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
            <div className="flex items-center justify-between gap-4 pt-4">
                <button type="button" onClick={onBack} className="bg-stone-200 dark:bg-slate-700 text-stone-800 dark:text-stone-200 px-6 py-2 rounded-md font-semibold hover:bg-stone-300 dark:hover:bg-slate-600 transition">Voltar</button>
                <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded-md font-semibold hover:bg-blue-700 transition">Entrar</button>
            </div>
        </form>
    );
};

const ProviderLoginForm: React.FC<{ onBack: () => void; onLogin: LoginModalProps['onLogin'] }> = ({ onBack, onLogin }) => {
    const [providerId, setProviderId] = useState('');
    const [password, setPassword] = useState('');

    const handleSimulatedLogin = (e: React.FormEvent) => {
        e.preventDefault();
        if (providerId && password) {
            onLogin({ type: 'provider', id: providerId, profileComplete: false }); // profileComplete: false for demo
        }
    };

    return (
        <form onSubmit={handleSimulatedLogin} className='space-y-4'>
            <h2 className="text-2xl font-bold text-center text-stone-800 dark:text-white">Login de Prestador</h2>
            <FormInput name="providerId" placeholder="Número de Cadastro" value={providerId} onChange={(e) => setProviderId(e.target.value)} required />
            <FormInput name="password" placeholder="Palavra-passe" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
            <div className="flex items-center justify-between gap-4 pt-4">
                <button type="button" onClick={onBack} className="bg-stone-200 dark:bg-slate-700 text-stone-800 dark:text-stone-200 px-6 py-2 rounded-md font-semibold hover:bg-stone-300 dark:hover:bg-slate-600 transition">Voltar</button>
                <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded-md font-semibold hover:bg-blue-700 transition">Entrar</button>
            </div>
        </form>
    );
};


const LoginSelector: React.FC<{ onSelect: (view: 'provider' | 'client') => void }> = ({ onSelect }) => (
    <div className="text-center">
        <h2 className="text-3xl font-bold mb-2 text-stone-900 dark:text-white">Bem-vindo de Volta</h2>
        <p className="text-stone-600 dark:text-stone-300 mb-8">Selecione o tipo de conta para fazer login.</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <button onClick={() => onSelect('provider')} className="p-8 border-2 border-stone-200 dark:border-slate-700 rounded-lg text-left hover:border-blue-500 dark:hover:border-blue-500 hover:bg-stone-50 dark:hover:bg-slate-700/50 transition-all transform hover:scale-105">
                <h3 className="text-xl font-bold text-blue-600 dark:text-blue-400">Sou Prestador de Serviço</h3>
                <p className="mt-2 text-stone-600 dark:text-stone-300">Aceda à sua área para gerir pedidos e o seu perfil.</p>
            </button>
            <button onClick={() => onSelect('client')} className="p-8 border-2 border-stone-200 dark:border-slate-700 rounded-lg text-left hover:border-blue-500 dark:hover:border-blue-500 hover:bg-stone-50 dark:hover:bg-slate-700/50 transition-all transform hover:scale-105">
                <h3 className="text-xl font-bold text-blue-600 dark:text-blue-400">Sou Cliente</h3>
                <p className="mt-2 text-stone-600 dark:text-stone-300">Aceda à sua conta para pedir orçamentos e ver o estado dos seus pedidos.</p>
            </button>
        </div>
    </div>
);


export const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose, onLogin }) => {
    const [view, setView] = useState<'select' | 'provider' | 'client'>('select');

    const handleClose = () => {
        onClose();
        setTimeout(() => setView('select'), 300);
    };

    const renderContent = () => {
        switch (view) {
            case 'provider': return <ProviderLoginForm onBack={() => setView('select')} onLogin={onLogin} />;
            case 'client': return <ClientLoginForm onBack={() => setView('select')} onLogin={onLogin} />;
            default: return <LoginSelector onSelect={setView} />;
        }
    };

    return <Modal isOpen={isOpen} onClose={handleClose}>{renderContent()}</Modal>;
};

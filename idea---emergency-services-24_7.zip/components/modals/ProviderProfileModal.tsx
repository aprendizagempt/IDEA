
import React, { useState } from 'react';
import { Modal } from './Modal';
import { ALL_SERVICES } from '../../constants';

interface ProviderProfileModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (profile: { category: string, zones: string, description: string }) => void;
}

export const ProviderProfileModal: React.FC<ProviderProfileModalProps> = ({ isOpen, onClose, onSave }) => {
    const [profile, setProfile] = useState({ category: '', zones: '', description: '' });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setProfile(prev => ({ ...prev, [name]: value }));
    };

    const handleSave = () => {
        onSave(profile);
        onClose();
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose}>
            <div className='space-y-6'>
                <h2 className="text-2xl font-bold text-center text-stone-800 dark:text-white">Configure o seu Perfil Público</h2>
                <p className="text-center text-stone-600 dark:text-stone-300">Esta informação será visível para os clientes. Por favor, preencha com atenção.</p>
                <div>
                    <label htmlFor="category-profile" className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-1">Qual é o seu serviço principal?</label>
                    <select id="category-profile" name="category" value={profile.category} onChange={handleChange} required className="w-full p-3 border border-stone-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:ring-blue-500 focus:border-blue-500">
                        <option value="">Selecione o seu serviço...</option>
                        {ALL_SERVICES.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                </div>
                <div>
                    <label htmlFor="zones" className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-1">Zonas de Atuação</label>
                    <input type='text' id='zones' name='zones' value={profile.zones} onChange={handleChange} placeholder='Ex: Lisboa, Porto, Sintra (separado por vírgulas)' className="w-full p-3 border border-stone-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:ring-blue-500 focus:border-blue-500" />
                </div>
                <div>
                    <label htmlFor="description-profile" className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-1">Breve descrição sobre o seu trabalho</label>
                    <textarea id="description-profile" name="description" value={profile.description} onChange={handleChange} rows={5} className="w-full p-3 border border-stone-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:ring-blue-500 focus:border-blue-500" placeholder="Descreva a sua experiência, especialidades, etc." />
                </div>
                <div className="bg-red-100 dark:bg-red-900/50 border-l-4 border-red-500 text-red-700 dark:text-red-300 p-4 rounded-md">
                    <p className="font-bold">Atenção: Regra da Plataforma</p>
                    <p className="text-sm">É estritamente proibido incluir qualquer informação de contacto (número de telefone, email, website, morada) nesta descrição. A violação desta regra resultará no banimento imediato da conta e na perda de qualquer valor de subscrição pago.</p>
                </div>
                <div className='flex justify-end pt-4'>
                    <button onClick={handleSave} className='bg-blue-600 text-white px-6 py-2 rounded-md font-semibold hover:bg-blue-700 transition'>Guardar Perfil</button>
                </div>
            </div>
        </Modal>
    );
};


import React, { useState, useMemo } from 'react';
import { Modal } from './Modal';
import { FormInput } from '../ui/FormInput';
import { FileInput } from '../ui/FileInput';
import { FormStatus } from '../ui/FormStatus';
import { PRICING_PLANS } from '../../constants';

interface RegistrationModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const ClientRegistrationForm: React.FC<{ onBack: () => void }> = ({ onBack }) => {
    const [formData, setFormData] = useState({ fullName: '', address: '', nif: '' });
    const [files, setFiles] = useState<{ idDocument: File | null, addressProof: File | null }>({ idDocument: null, addressProof: null });
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [touched, setTouched] = useState<Record<string, boolean>>({});
    const [status, setStatus] = useState<'submitting' | 'success' | 'error' | null>(null);
    const FORMSPREE_ENDPOINT = "https://formspree.io/f/movnrrzj"; // Replace with your actual endpoint

    const validateField = (name: string, value: string) => {
        if (!value.trim()) return 'Este campo é obrigatório.';
        if (name === 'nif' && !/^\d{9}$/.test(value)) return 'O NIF deve ter 9 dígitos.';
        return '';
    };

    const validateFile = (file: File | null) => !file ? 'É necessário carregar este documento.' : '';

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
        if (touched[name]) {
            setErrors(prev => ({ ...prev, [name]: validateField(name, value) }));
        }
    };

    const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setTouched(prev => ({ ...prev, [name]: true }));
        setErrors(prev => ({ ...prev, [name]: validateField(name, value) }));
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, files: selectedFiles } = e.target;
        const file = selectedFiles?.[0] || null;
        setFiles(prev => ({ ...prev, [name]: file }));
        setTouched(prev => ({ ...prev, [name]: true }));
        setErrors(prev => ({ ...prev, [name]: validateFile(file) }));
    };

    const isFormValid = useMemo(() => {
        return Object.keys(formData).every(key => !validateField(key, formData[key as keyof typeof formData])) &&
               Object.keys(files).every(key => !validateFile(files[key as keyof typeof files]));
    }, [formData, files]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        // Mark all as touched
        const allTouched = { ...formData, ...files };
        Object.keys(allTouched).forEach(key => setTouched(prev => ({...prev, [key]: true})));
        
        // Validate all
        const newErrors: Record<string, string> = {};
        Object.keys(formData).forEach(key => newErrors[key] = validateField(key, formData[key as keyof typeof formData]));
        Object.keys(files).forEach(key => newErrors[key] = validateFile(files[key as keyof typeof files]));
        setErrors(newErrors);

        if (Object.values(newErrors).some(err => err)) return;

        setStatus('submitting');
        const data = new FormData();
        data.append('form-type', 'Client Registration');
        // FIX: Replaced Object.entries with Object.keys to resolve type inference issues,
        // ensuring values appended to FormData are correctly typed as string or Blob.
        Object.keys(formData).forEach(key => {
            data.append(key, formData[key as keyof typeof formData]);
        });
        Object.keys(files).forEach(key => {
            const file = files[key as keyof typeof files];
            if (file) {
                data.append(key, file);
            }
        });

        try {
            const response = await fetch(FORMSPREE_ENDPOINT, { method: 'POST', body: data, headers: { 'Accept': 'application/json' } });
            if (response.ok) setStatus('success'); else setStatus('error');
        } catch (error) { setStatus('error'); }
    };

    if (status === 'success') {
        return (
            <div className="text-center p-8">
                <h2 className="text-2xl font-bold text-stone-800 dark:text-white mb-4">Registo Enviado!</h2>
                <p className="text-stone-600 dark:text-stone-300">Obrigado pelo seu registo. Entraremos em contacto em breve para finalizar o processo.</p>
            </div>
        );
    }
    
    return (
        <form onSubmit={handleSubmit} noValidate className="space-y-4">
            <h2 className="text-2xl font-bold text-center text-stone-800 dark:text-white">Registo de Cliente</h2>
            <FormInput name="fullName" placeholder="Nome Completo" required value={formData.fullName} onChange={handleChange} onBlur={handleBlur} error={touched.fullName ? errors.fullName : ''} />
            <FormInput name="address" placeholder="Endereço Completo" required value={formData.address} onChange={handleChange} onBlur={handleBlur} error={touched.address ? errors.address : ''} />
            <FormInput name="nif" placeholder="NIF" required value={formData.nif} onChange={handleChange} onBlur={handleBlur} error={touched.nif ? errors.nif : ''} />
            <FileInput id="idDocumentClient" name="idDocument" label="Cópia do Cartão de Cidadão" required file={files.idDocument} onChange={handleFileChange} error={touched.idDocument ? errors.idDocument : ''} />
            <FileInput id="addressProofClient" name="addressProof" label="Comprovativo de Morada" required file={files.addressProof} onChange={handleFileChange} error={touched.addressProof ? errors.addressProof : ''} />
            {status === 'error' && <FormStatus status="error" message="Ocorreu um erro ao enviar o seu registo. Por favor, tente novamente." />}
            <div className="flex items-center justify-between gap-4 pt-4">
                <button type="button" onClick={onBack} className="bg-stone-200 dark:bg-slate-700 text-stone-800 dark:text-stone-200 px-6 py-2 rounded-md font-semibold hover:bg-stone-300 dark:hover:bg-slate-600 transition">Voltar</button>
                <button type="submit" disabled={!isFormValid || status === 'submitting'} className="bg-blue-600 text-white px-6 py-2 rounded-md font-semibold hover:bg-blue-700 transition disabled:bg-blue-400 disabled:cursor-not-allowed">
                    {status === 'submitting' ? 'A Enviar...' : 'Registar'}
                </button>
            </div>
        </form>
    );
};


const CompanyRegistrationForm: React.FC<{ onBack: () => void }> = ({ onBack }) => {
    // Simplified logic from the original file
    const [status, setStatus] = useState<'submitting' | 'success' | 'error' | null>(null);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setStatus('submitting');
        // Fake submission for demo
        setTimeout(() => setStatus('success'), 1000);
    };

     if (status === 'success') {
        return (
            <div className="text-center p-8">
                <h2 className="text-2xl font-bold text-stone-800 dark:text-white mb-4">Registo Enviado!</h2>
                <p className="text-stone-600 dark:text-stone-300">Obrigado pelo seu registo. A sua candidatura será analisada e entraremos em contacto em breve.</p>
                <p className="text-sm text-stone-500 dark:text-stone-400 mt-2">Lembre-se: os primeiros 3 meses são grátis (excluindo comissões de serviço).</p>
            </div>
        );
    }
    
    return (
         <form onSubmit={handleSubmit} noValidate className="space-y-4">
            <h2 className="text-2xl font-bold text-center text-stone-800 dark:text-white">Registo de Empresa / Profissional</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormInput name="companyName" placeholder="Nome da Empresa" required value="" onChange={() => {}} />
                <FormInput name="managerName" placeholder="Nome do Gerente/Patrão" required value="" onChange={() => {}} />
                <FormInput name="nif" placeholder="NIF Empresarial" required value="" onChange={() => {}} />
                <FormInput name="contact" placeholder="Contacto (Telefone/Email)" required value="" onChange={() => {}} />
            </div>
            <FormInput name="address" placeholder="Endereço da Empresa" required value="" onChange={() => {}} />
            <div className="space-y-4">
                <h3 className="text-lg font-semibold text-stone-800 dark:text-white">Validação de Documentos</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FileInput id="idDocumentCompany" name="idDocument" label="BI/Cartão Cidadão" required file={null} onChange={() => {}} />
                    <FileInput id="addressProofCompany" name="addressProof" label="Comprovativo Morada" required file={null} onChange={() => {}} />
                    <FileInput id="businessProofCompany" name="businessProof" label="Comprovativo Empresa" required file={null} onChange={() => {}} />
                </div>
            </div>
            <div>
                <h3 className="text-lg font-semibold text-stone-800 dark:text-white mb-2">Escolha o seu Plano</h3>
                <p className="text-sm text-stone-500 dark:text-stone-400 mb-4">Os primeiros 3 meses são grátis! Após o período de teste, será aplicada a mensalidade do plano escolhido.</p>
                <div className="w-full">
                    <select name="plan" defaultValue="Profissional Plus" className="w-full p-3 border border-stone-300 dark:border-slate-600 rounded-md bg-white dark:bg-slate-700 focus:ring-blue-500 focus:border-blue-500">
                        {PRICING_PLANS.filter(p => !p.isCustom).map(plan => <option key={plan.name} value={plan.name}>{`Plano ${plan.name} (${plan.price}€)`}</option>)}
                    </select>
                </div>
            </div>
            <div className="flex items-center justify-between gap-4 pt-4">
                <button type="button" onClick={onBack} className="bg-stone-200 dark:bg-slate-700 text-stone-800 dark:text-stone-200 px-6 py-2 rounded-md font-semibold hover:bg-stone-300 dark:hover:bg-slate-600 transition">Voltar</button>
                <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded-md font-semibold hover:bg-blue-700 transition">
                     {status === 'submitting' ? 'A Enviar...' : 'Registar'}
                </button>
            </div>
        </form>
    )
}

const RegistrationSelector: React.FC<{ onSelect: (view: 'company' | 'client') => void }> = ({ onSelect }) => (
    <div className="text-center">
        <h2 className="text-3xl font-bold mb-2 text-stone-900 dark:text-white">Junte-se à IDEA</h2>
        <p className="text-stone-600 dark:text-stone-300 mb-8">Selecione o tipo de conta que pretende criar.</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <button onClick={() => onSelect('company')} className="p-8 border-2 border-stone-200 dark:border-slate-700 rounded-lg text-left hover:border-blue-500 dark:hover:border-blue-500 hover:bg-stone-50 dark:hover:bg-slate-700/50 transition-all transform hover:scale-105">
                <h3 className="text-xl font-bold text-blue-600 dark:text-blue-400">Sou uma Empresa / Profissional</h3>
                <p className="mt-2 text-stone-600 dark:text-stone-300">Quero oferecer os meus serviços, encontrar novos clientes e aumentar o meu negócio.</p>
            </button>
            <button onClick={() => onSelect('client')} className="p-8 border-2 border-stone-200 dark:border-slate-700 rounded-lg text-left hover:border-blue-500 dark:hover:border-blue-500 hover:bg-stone-50 dark:hover:bg-slate-700/50 transition-all transform hover:scale-105">
                <h3 className="text-xl font-bold text-blue-600 dark:text-blue-400">Sou um Cliente</h3>
                <p className="mt-2 text-stone-600 dark:text-stone-300">Preciso de encontrar profissionais qualificados para resolver um problema ou para um projeto.</p>
            </button>
        </div>
    </div>
);


export const RegistrationModal: React.FC<RegistrationModalProps> = ({ isOpen, onClose }) => {
    const [view, setView] = useState<'select' | 'company' | 'client'>('select');

    const handleClose = () => {
        onClose();
        setTimeout(() => setView('select'), 300); // Reset view after closing animation
    };

    const renderContent = () => {
        switch (view) {
            case 'company': return <CompanyRegistrationForm onBack={() => setView('select')} />;
            case 'client': return <ClientRegistrationForm onBack={() => setView('select')} />;
            default: return <RegistrationSelector onSelect={setView} />;
        }
    };

    return <Modal isOpen={isOpen} onClose={handleClose}>{renderContent()}</Modal>;
};


import React from 'react';

interface FormInputProps {
    name: string;
    placeholder: string;
    required?: boolean;
    value: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onBlur?: (e: React.FocusEvent<HTMLInputElement>) => void;
    error?: string;
    type?: string;
}

export const FormInput: React.FC<FormInputProps> = ({ name, placeholder, required, value, onChange, onBlur, error, type = "text" }) => {
    return (
        <div className="w-full">
            <input
                type={type}
                name={name}
                placeholder={required ? `${placeholder} *` : placeholder}
                required={required}
                value={value}
                onChange={onChange}
                onBlur={onBlur}
                className={`w-full p-3 border ${error ? 'border-red-500' : 'border-stone-300 dark:border-slate-600'} rounded-md bg-white dark:bg-slate-700 focus:ring-2 ${error ? 'focus:ring-red-500' : 'focus:ring-blue-500'} focus:border-transparent outline-none`}
            />
            {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
        </div>
    );
};

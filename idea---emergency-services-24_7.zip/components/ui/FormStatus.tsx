
import React from 'react';

interface FormStatusProps {
    status: 'success' | 'error';
    message: string;
}

export const FormStatus: React.FC<FormStatusProps> = ({ status, message }) => {
    const isSuccess = status === 'success';
    const bgColor = isSuccess ? 'bg-green-100 dark:bg-green-900/50' : 'bg-red-100 dark:bg-red-900/50';
    const borderColor = isSuccess ? 'border-green-500' : 'border-red-500';
    const textColor = isSuccess ? 'text-green-700 dark:text-green-300' : 'text-red-700 dark:text-red-300';

    return (
        <div className={`${bgColor} border-l-4 ${borderColor} ${textColor} p-4 rounded-md my-4`}>
            <p className="font-bold">{isSuccess ? 'Sucesso!' : 'Erro!'}</p>
            <p>{message}</p>
        </div>
    );
};

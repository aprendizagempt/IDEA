
import React from 'react';
export const TruckIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M5.625 3.75a2.25 2.25 0 0 1 2.25 2.25v.75h-2.25a.75.75 0 0 0-.75.75v3a.75.75 0 0 0 .75.75h2.25v.75a2.25 2.25 0 0 1-2.25 2.25H3.75a.75.75 0 0 1-.75-.75V8.625a.75.75 0 0 0-.75-.75H1.5a.75.75 0 0 1-.75-.75V5.25a.75.75 0 0 1 .75-.75h2.25a.75.75 0 0 0 .75-.75V3.75Z" />
    <path fillRule="evenodd" d="M8.625 3.75a.75.75 0 0 1 .75.75v15a.75.75 0 0 1-.75.75H6.375a3 3 0 0 1-3-3V6.75a3 3 0 0 1 3-3h2.25ZM11.625 3a.75.75 0 0 0-.75.75v16.5a.75.75 0 0 0 .75.75h5.25a3.75 3.75 0 0 0 3.75-3.75V15a3 3 0 0 0-3-3h-1.5V5.25a2.25 2.25 0 0 0-2.25-2.25h-2.25Z" clipRule="evenodd" />
  </svg>
);

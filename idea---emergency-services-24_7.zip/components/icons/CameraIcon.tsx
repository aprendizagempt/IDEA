
import React from 'react';
export const CameraIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M4.5 4.5a3 3 0 00-3 3v9a3 3 0 003 3h15a3 3 0 003-3v-9a3 3 0 00-3-3h-1.875a1.5 1.5 0 01-1.06-.44l-1.125-1.125a1.5 1.5 0 00-1.06-.44H9.75a1.5 1.5 0 00-1.06.44L7.563 7.06a1.5 1.5 0 01-1.06.44H4.5z" />
    <path d="M12 11.25a3.75 3.75 0 100 7.5 3.75 3.75 0 000-7.5zM12 13.5a1.5 1.5 0 110 3 1.5 1.5 0 010-3z" />
  </svg>
);

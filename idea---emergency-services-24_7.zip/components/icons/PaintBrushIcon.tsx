
import React from 'react';
export const PaintBrushIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M11.625 1.5a2.25 2.25 0 0 1 2.25 2.25V7.5h-4.5V3.75a2.25 2.25 0 0 1 2.25-2.25Z" />
    <path d="M11.625 1.5a.75.75 0 0 1 .75.75V3h-1.5V2.25a.75.75 0 0 1 .75-.75Z" />
    <path fillRule="evenodd" d="M19.5 7.5h-15a.75.75 0 0 0-.75.75v12a.75.75 0 0 0 .75.75h15a.75.75 0 0 0 .75-.75v-12a.75.75 0 0 0-.75-.75Zm-15 1.5h15V18h-15V9Zm-2.25-1.5a2.25 2.25 0 0 0-2.25 2.25v9.75a2.25 2.25 0 0 0 2.25 2.25h19.5a2.25 2.25 0 0 0 2.25-2.25V9.75a2.25 2.25 0 0 0-2.25-2.25H2.25Z" clipRule="evenodd" />
  </svg>
);

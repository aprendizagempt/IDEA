
import React from 'react';
export const CarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M3.283 6.042a.75.75 0 01.99-.073l3.901 2.25a.75.75 0 010 1.326l-3.9 2.252a.75.75 0 01-.99-.072L.73 7.373a.75.75 0 010-1.326l2.552-1.475zM8.25 7.5a.75.75 0 01.75-.75h12a.75.75 0 01.75.75v10.5a.75.75 0 01-.75.75h-12a.75.75 0 01-.75-.75V7.5z" clipRule="evenodd" />
  </svg>
);

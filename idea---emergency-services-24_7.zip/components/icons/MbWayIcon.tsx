
import React from 'react';
export const MbWayIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg fill="none" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" {...props}>
    <rect width="100" height="100" rx="22" fill="white" />
    <path d="M69.5833 30.0833H30.4167C28.4355 30.0833 26.8333 31.6855 26.8333 33.6667V66.3333C26.8333 68.3145 28.4355 69.9167 30.4167 69.9167H69.5833C71.5645 69.9167 73.1667 68.3145 73.1667 66.3333V33.6667C73.1667 31.6855 71.5645 30.0833 69.5833 30.0833Z" stroke="#D00014" strokeWidth="5" strokeLinejoin="round" />
    <path d="M43.7917 43.125V56.875L36.625 50L43.7917 43.125Z" fill="black" />
    <path d="M51.2917 56.875H57.875L63.375 43.125H56.7917L54.0833 50.8333L51.2917 56.875Z" fill="black" />
  </svg>
);

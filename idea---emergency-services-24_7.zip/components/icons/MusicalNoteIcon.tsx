
import React from 'react';
export const MusicalNoteIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M10.5 4.5a.75.75 0 00-1.5 0v10.337A2.25 2.25 0 007.5 15a2.25 2.25 0 00-2.25 2.25c0 .53.184 1.01.494 1.393a.75.75 0 101.112-1.006A.75.75 0 017.5 16.5a.75.75 0 01.75-.75c.172 0 .332.058.468.156V4.5z" />
    <path d="M16.5 3a.75.75 0 00-1.5 0v10.337A2.25 2.25 0 0013.5 13.5a2.25 2.25 0 00-2.25 2.25c0 .53.184 1.01.494 1.393a.75.75 0 101.112-1.006A.75.75 0 0113.5 15a.75.75 0 01.75-.75c.172 0 .332.058.468.156V3z" />
  </svg>
);

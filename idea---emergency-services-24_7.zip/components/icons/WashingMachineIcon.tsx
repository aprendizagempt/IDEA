
import React from 'react';
export const WashingMachineIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M1.5 3.75A2.25 2.25 0 013.75 1.5h16.5A2.25 2.25 0 0122.5 3.75v16.5A2.25 2.25 0 0120.25 22.5H3.75A2.25 2.25 0 011.5 20.25V3.75zm3.75 2.25a.75.75 0 000 1.5h13.5a.75.75 0 000-1.5H5.25zM12 10.5a4.5 4.5 0 100 9 4.5 4.5 0 000-9zm-2.25 4.5a2.25 2.25 0 114.5 0 2.25 2.25 0 01-4.5 0z" clipRule="evenodd" />
  </svg>
);

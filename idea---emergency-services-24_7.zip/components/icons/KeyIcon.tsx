
import React from 'react';
export const KeyIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M15.75 1.5a3 3 0 00-3 3V6a3 3 0 00-3 3v.75a3 3 0 00-3 3v3.75a3 3 0 003 3h3.75a3 3 0 003-3V9.75a3 3 0 00-3-3V6a3 3 0 003-3h.75a3 3 0 003-3h-3.75zM12.75 12.75a.75.75 0 00-1.5 0v1.5a.75.75 0 001.5 0v-1.5z" clipRule="evenodd" />
  </svg>
);


import React from 'react';
export const BuildingStorefrontIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M12.378 1.602a.75.75 0 00-.756 0L3 7.225V21a.75.75 0 00.75.75h6a.75.75 0 00.75-.75v-7.5a.75.75 0 01.75-.75h3a.75.75 0 01.75.75V21a.75.75 0 00.75.75h6a.75.75 0 00.75-.75V7.225l-8.622-5.623zM16.5 18.75a.75.75 0 000-1.5h-3a.75.75 0 000 1.5h3z" />
    <path d="M21 4.755a.75.75 0 00-1.08-.626l-8.311 5.421a1.5 1.5 0 01-1.218 0l-8.311-5.421A.75.75 0 003 4.755v-.011a.75.75 0 00.578-.679l.666-3.329A.75.75 0 014.99 0h14.02a.75.75 0 01.744.736l.666 3.329a.75.75 0 00.578.679v.01z" />
  </svg>
);


import React from 'react';
export const StarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M10.868 2.884c.321-.662 1.215-.662 1.536 0l1.82 3.755 4.137.602c.73.106 1.022.992.494 1.503l-2.994 2.918.707 4.12c.125.726-.638 1.282-1.296.953L10 15.175l-3.705 1.948c-.658.33-1.422-.227-1.296-.953l.707-4.12-2.994-2.918c-.528-.51-.236-1.397.494-1.503l4.137-.602 1.82-3.755Z" clipRule="evenodd" />
  </svg>
);


import React from 'react';
export const MastercardIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 38 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <circle cx="12" cy="12" r="12" fill="#EA001B" />
    <circle cx="26" cy="12" r="12" fill="#F79E1B" />
    <path d="M22.997 12C22.997 18.075 18.075 23 12.001 23C10.598 23 9.255 22.746 8.01 22.285C11.973 19.832 14.802 15.65 15.54 11.03C15.932 8.356 15.63 5.63 14.73 3.118C16.59 1.764 18.82 1 21.25 1C24.498 1 27.35 2.65 29.21 5.16C25.53 6.84 23 9.9 23 12H22.997Z" fill="#FF5F00" />
  </svg>
);

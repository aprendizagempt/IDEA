
import React from 'react';
export const BriefcaseIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M10.5 1.5H8.25A2.25 2.25 0 006 3.75v16.5a2.25 2.25 0 002.25 2.25h7.5A2.25 2.25 0 0018 20.25V3.75A2.25 2.25 0 0015.75 1.5h-2.25a.75.75 0 00-1.5 0v3a.75.75 0 01-1.5 0v-3a.75.75 0 00-.75-.75zM10.5 6a.75.75 0 00-1.5 0v3a.75.75 0 001.5 0v-3zM12 1.5a.75.75 0 01.75.75v3a.75.75 0 01-1.5 0v-3A.75.75 0 0112 1.5z" />
    <path fillRule="evenodd" d="M3 6.75A2.25 2.25 0 015.25 4.5h13.5A2.25 2.25 0 0121 6.75v10.5A2.25 2.25 0 0118.75 19.5H5.25A2.25 2.25 0 013 17.25V6.75zm15-1.5a.75.75 0 00-1.5 0v.75a.75.75 0 001.5 0v-.75zM5.25 6a.75.75 0 00-1.5 0v.75a.75.75 0 001.5 0V6z" clipRule="evenodd" />
  </svg>
);

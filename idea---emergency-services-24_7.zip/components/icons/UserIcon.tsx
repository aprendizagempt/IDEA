
import React from 'react';
export const UserIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM8.75 6.25a.75.75 0 00-1.5 0v3.5a.75.75 0 00.75.75h2a.75.75 0 000-1.5H9.5v-2.75z" clipRule="evenodd" />
  </svg>
);

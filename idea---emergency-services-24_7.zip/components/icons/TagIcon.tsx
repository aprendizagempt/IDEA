
import React from 'react';
export const TagIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path d="M3.5 2A1.5 1.5 0 002 3.5v9A1.5 1.5 0 003.5 14h6.086a1.5 1.5 0 001.06-.44l5-5a1.5 1.5 0 000-2.12l-5-5A1.5 1.5 0 009.586 2H3.5zM6 6a1 1 0 100-2 1 1 0 000 2z" />
  </svg>
);


import React from 'react';
export const ComputerDesktopIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M11.25 12.75a.75.75 0 000 1.5h1.5a.75.75 0 000-1.5h-1.5z" />
    <path fillRule="evenodd" d="M4.125 3C3.089 3 2.25 3.84 2.25 4.875v10.5C2.25 16.16 3.089 17 4.125 17h15.75c1.036 0 1.875-.84 1.875-1.875V4.875C21.75 3.839 20.911 3 19.875 3H4.125zM3.75 15.375V4.875c0-.207.168-.375.375-.375h15.75c.207 0 .375.168.375.375v10.5c0 .207-.168.375-.375.375H4.125c-.207 0-.375-.168-.375-.375zM6.75 18.75a.75.75 0 000 1.5h10.5a.75.75 0 000-1.5H6.75z" clipRule="evenodd" />
  </svg>
);
